-- Script gerado automaticamente pelo DevStudio (MVC Creator)
CREATE DATABASE IF NOT EXISTS `mvc_creator` DEFAULT CHARACTER SET utf8mb4;
USE `mvc_creator`;

CREATE TABLE IF NOT EXISTS `atributo` (
    `id_atributo` int(11) NOT NULL AUTO_INCREMENT,
    `fk_tabela` int(11) NOT NULL,
    `fk_atributo` int(11),
    `nome_atributo` varchar(60) NOT NULL,
    `tipo` tinytext NOT NULL,
    `PK` tinyint(4) NOT NULL,
    `NN` tinyint(4) NOT NULL,
    `AI` tinyint(4) NOT NULL,
    `UQ` tinyint(4) NOT NULL,
    PRIMARY KEY (`id_atributo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `banco` (
    `id_banco` int(11) NOT NULL AUTO_INCREMENT,
    `fk_usuario` int(11) NOT NULL,
    `nome_banco` varchar(60) NOT NULL,
    `usuario_banco` varchar(60) NOT NULL,
    `senha_banco` varchar(255),
    `host` varchar(20) NOT NULL,
    `porta` varchar(10) NOT NULL,
    PRIMARY KEY (`id_banco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `estilo` (
    `id_estilo` int(11) NOT NULL AUTO_INCREMENT,
    `nome_arquivo` varchar(60),
    `texto_cabecalho` varchar(100),
    `titulo_aba` varchar(100),
    `cor_fundo` varchar(20) NOT NULL,
    `cor_fonte` varchar(20) NOT NULL,
    `tamanho_fonte` varchar(20) NOT NULL,
    `tipo_layout` varchar(10) NOT NULL,
    `alinhamento_horizontal` varchar(20) NOT NULL,
    `alinhamento_vertical` varchar(20) NOT NULL,
    `margem_pagina` int(11) NOT NULL,
    `preenchimento_pagina` int(11) NOT NULL,
    `cabecalho_fixo` tinyint(1) NOT NULL,
    `url_fonte` varchar(255),
    `peso_fonte` varchar(10) NOT NULL,
    `altura_linha` decimal(3,1) NOT NULL,
    `raio_borda` int(11) NOT NULL,
    `tipo_sombra` varchar(20) NOT NULL,
    `imagem_fundo` varchar(255),
    `cor_gradiente_inicial` varchar(20) NOT NULL,
    `cor_gradiente_final` varchar(20) NOT NULL,
    `opacidade_fundo` int(11) NOT NULL,
    `sem_navegacao` tinyint(1) NOT NULL,
    `cor_links` varchar(20) NOT NULL,
    `estilo_links` tinyint(1) NOT NULL,
    `links` text,
    `texto_pagina` mediumtext,
    `nome_imagem` varchar(100),
    `url_imagem` varchar(255),
    `largura_imagem` int(11),
    `alt_imagem` varchar(100),
    `alt_text_imagem` varchar(100),
    `incluir_lista` tinyint(1) NOT NULL,
    `incluir_tabela` tinyint(1) NOT NULL,
    `incluir_rodape` tinyint(1) NOT NULL,
    `incluir_card` tinyint(1) NOT NULL,
    `incluir_formulario` tinyint(1) NOT NULL,
    `texto_botao` varchar(60) NOT NULL,
    `link_botao` varchar(255) NOT NULL,
    `cor_botao` varchar(20) NOT NULL,
    `cor_botao_hover` varchar(20) NOT NULL,
    `ordem_elementos` varchar(50) NOT NULL,
    `css_customizado` mediumtext,
    `html_customizado` mediumtext,
    PRIMARY KEY (`id_estilo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `log` (
    `id_log` int(11) NOT NULL AUTO_INCREMENT,
    `acao` varchar(255) NOT NULL,
    `data` datetime NOT NULL,
    `fk_usuario` int(11) NOT NULL,
    PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `projeto` (
    `id_projeto` int(11) NOT NULL AUTO_INCREMENT,
    `id_usuario` int(11) NOT NULL,
    `fk_banco` int(11),
    `fk_estilo` int(11) UNIQUE,
    `ultimo_download` int(11),
    `nome_projeto` varchar(60) NOT NULL,
    `data_criacao` datetime NOT NULL,
    `prazo_de_vida` int(11) NOT NULL,
    `caminho_armazenamento` varchar(255) NOT NULL,
    `comentarios` tinyint(4) NOT NULL,
    `views` tinyint(4) NOT NULL,
    PRIMARY KEY (`id_projeto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `tabela` (
    `id_tabela` int(11) NOT NULL AUTO_INCREMENT,
    `nome_tabela` varchar(60) NOT NULL,
    `fk_banco` int(11) NOT NULL,
    PRIMARY KEY (`id_tabela`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `usuario` (
    `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
    `email` varchar(60) NOT NULL,
    `senha_usuario` varchar(255) NOT NULL,
    `tipo_perfil` enum('admin','usuario') NOT NULL,
    `nome` varchar(60) NOT NULL,
    PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Chaves estrangeiras
ALTER TABLE `atributo` ADD CONSTRAINT `fk_atributo_fk_tabela` FOREIGN KEY (`fk_tabela`) REFERENCES `tabela` (`id_tabela`);
ALTER TABLE `atributo` ADD CONSTRAINT `fk_atributo_fk_atributo` FOREIGN KEY (`fk_atributo`) REFERENCES `atributo` (`id_atributo`);
ALTER TABLE `banco` ADD CONSTRAINT `fk_banco_fk_usuario` FOREIGN KEY (`fk_usuario`) REFERENCES `usuario` (`id_usuario`);
ALTER TABLE `log` ADD CONSTRAINT `fk_log_fk_usuario` FOREIGN KEY (`fk_usuario`) REFERENCES `usuario` (`id_usuario`);
ALTER TABLE `projeto` ADD CONSTRAINT `fk_projeto_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`);
ALTER TABLE `projeto` ADD CONSTRAINT `fk_projeto_fk_banco` FOREIGN KEY (`fk_banco`) REFERENCES `banco` (`id_banco`);
ALTER TABLE `projeto` ADD CONSTRAINT `fk_projeto_fk_estilo` FOREIGN KEY (`fk_estilo`) REFERENCES `estilo` (`id_estilo`);
ALTER TABLE `projeto` ADD CONSTRAINT `fk_projeto_ultimo_download` FOREIGN KEY (`ultimo_download`) REFERENCES `log` (`id_log`);
ALTER TABLE `tabela` ADD CONSTRAINT `fk_tabela_fk_banco` FOREIGN KEY (`fk_banco`) REFERENCES `banco` (`id_banco`);
