<?php

namespace app\services;

use app\models\Estilo;
use app\repositories\EstiloRepository;

class EstiloService {
    private EstiloRepository $repository;

    public function __construct() {
        $this->repository = new EstiloRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Estilo $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Estilo $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
