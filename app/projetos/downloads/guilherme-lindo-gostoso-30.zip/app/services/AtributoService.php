<?php

namespace app\services;

use app\models\Atributo;
use app\repositories\AtributoRepository;

class AtributoService {
    private AtributoRepository $repository;

    public function __construct() {
        $this->repository = new AtributoRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Atributo $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Atributo $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
