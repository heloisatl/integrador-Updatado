<?php

namespace app\services;

use app\models\Banco;
use app\repositories\BancoRepository;

class BancoService {
    private BancoRepository $repository;

    public function __construct() {
        $this->repository = new BancoRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Banco $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Banco $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
