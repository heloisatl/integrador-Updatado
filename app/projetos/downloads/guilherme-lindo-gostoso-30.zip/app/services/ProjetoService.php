<?php

namespace app\services;

use app\models\Projeto;
use app\repositories\ProjetoRepository;

class ProjetoService {
    private ProjetoRepository $repository;

    public function __construct() {
        $this->repository = new ProjetoRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Projeto $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Projeto $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
