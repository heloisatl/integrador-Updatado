<?php

namespace app\services;

use app\models\Tabela;
use app\repositories\TabelaRepository;

class TabelaService {
    private TabelaRepository $repository;

    public function __construct() {
        $this->repository = new TabelaRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Tabela $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Tabela $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
