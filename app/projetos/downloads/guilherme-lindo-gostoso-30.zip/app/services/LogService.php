<?php

namespace app\services;

use app\models\Log;
use app\repositories\LogRepository;

class LogService {
    private LogRepository $repository;

    public function __construct() {
        $this->repository = new LogRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Log $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Log $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
