<?php

namespace app\models;

class Estilo {
    private $id_estilo;
    private $nome_arquivo;
    private $texto_cabecalho;
    private $titulo_aba;
    private $cor_fundo;
    private $cor_fonte;
    private $tamanho_fonte;
    private $tipo_layout;
    private $alinhamento_horizontal;
    private $alinhamento_vertical;
    private $margem_pagina;
    private $preenchimento_pagina;
    private $cabecalho_fixo;
    private $url_fonte;
    private $peso_fonte;
    private $altura_linha;
    private $raio_borda;
    private $tipo_sombra;
    private $imagem_fundo;
    private $cor_gradiente_inicial;
    private $cor_gradiente_final;
    private $opacidade_fundo;
    private $sem_navegacao;
    private $cor_links;
    private $estilo_links;
    private $links;
    private $texto_pagina;
    private $nome_imagem;
    private $url_imagem;
    private $largura_imagem;
    private $alt_imagem;
    private $alt_text_imagem;
    private $incluir_lista;
    private $incluir_tabela;
    private $incluir_rodape;
    private $incluir_card;
    private $incluir_formulario;
    private $texto_botao;
    private $link_botao;
    private $cor_botao;
    private $cor_botao_hover;
    private $ordem_elementos;
    private $css_customizado;
    private $html_customizado;

    public function getId_estilo() {
        return $this->id_estilo;
    }

    public function setId_estilo($id_estilo) {
        $this->id_estilo = $id_estilo;
    }

    public function getNome_arquivo() {
        return $this->nome_arquivo;
    }

    public function setNome_arquivo($nome_arquivo) {
        $this->nome_arquivo = $nome_arquivo;
    }

    public function getTexto_cabecalho() {
        return $this->texto_cabecalho;
    }

    public function setTexto_cabecalho($texto_cabecalho) {
        $this->texto_cabecalho = $texto_cabecalho;
    }

    public function getTitulo_aba() {
        return $this->titulo_aba;
    }

    public function setTitulo_aba($titulo_aba) {
        $this->titulo_aba = $titulo_aba;
    }

    public function getCor_fundo() {
        return $this->cor_fundo;
    }

    public function setCor_fundo($cor_fundo) {
        $this->cor_fundo = $cor_fundo;
    }

    public function getCor_fonte() {
        return $this->cor_fonte;
    }

    public function setCor_fonte($cor_fonte) {
        $this->cor_fonte = $cor_fonte;
    }

    public function getTamanho_fonte() {
        return $this->tamanho_fonte;
    }

    public function setTamanho_fonte($tamanho_fonte) {
        $this->tamanho_fonte = $tamanho_fonte;
    }

    public function getTipo_layout() {
        return $this->tipo_layout;
    }

    public function setTipo_layout($tipo_layout) {
        $this->tipo_layout = $tipo_layout;
    }

    public function getAlinhamento_horizontal() {
        return $this->alinhamento_horizontal;
    }

    public function setAlinhamento_horizontal($alinhamento_horizontal) {
        $this->alinhamento_horizontal = $alinhamento_horizontal;
    }

    public function getAlinhamento_vertical() {
        return $this->alinhamento_vertical;
    }

    public function setAlinhamento_vertical($alinhamento_vertical) {
        $this->alinhamento_vertical = $alinhamento_vertical;
    }

    public function getMargem_pagina() {
        return $this->margem_pagina;
    }

    public function setMargem_pagina($margem_pagina) {
        $this->margem_pagina = $margem_pagina;
    }

    public function getPreenchimento_pagina() {
        return $this->preenchimento_pagina;
    }

    public function setPreenchimento_pagina($preenchimento_pagina) {
        $this->preenchimento_pagina = $preenchimento_pagina;
    }

    public function getCabecalho_fixo() {
        return $this->cabecalho_fixo;
    }

    public function setCabecalho_fixo($cabecalho_fixo) {
        $this->cabecalho_fixo = $cabecalho_fixo;
    }

    public function getUrl_fonte() {
        return $this->url_fonte;
    }

    public function setUrl_fonte($url_fonte) {
        $this->url_fonte = $url_fonte;
    }

    public function getPeso_fonte() {
        return $this->peso_fonte;
    }

    public function setPeso_fonte($peso_fonte) {
        $this->peso_fonte = $peso_fonte;
    }

    public function getAltura_linha() {
        return $this->altura_linha;
    }

    public function setAltura_linha($altura_linha) {
        $this->altura_linha = $altura_linha;
    }

    public function getRaio_borda() {
        return $this->raio_borda;
    }

    public function setRaio_borda($raio_borda) {
        $this->raio_borda = $raio_borda;
    }

    public function getTipo_sombra() {
        return $this->tipo_sombra;
    }

    public function setTipo_sombra($tipo_sombra) {
        $this->tipo_sombra = $tipo_sombra;
    }

    public function getImagem_fundo() {
        return $this->imagem_fundo;
    }

    public function setImagem_fundo($imagem_fundo) {
        $this->imagem_fundo = $imagem_fundo;
    }

    public function getCor_gradiente_inicial() {
        return $this->cor_gradiente_inicial;
    }

    public function setCor_gradiente_inicial($cor_gradiente_inicial) {
        $this->cor_gradiente_inicial = $cor_gradiente_inicial;
    }

    public function getCor_gradiente_final() {
        return $this->cor_gradiente_final;
    }

    public function setCor_gradiente_final($cor_gradiente_final) {
        $this->cor_gradiente_final = $cor_gradiente_final;
    }

    public function getOpacidade_fundo() {
        return $this->opacidade_fundo;
    }

    public function setOpacidade_fundo($opacidade_fundo) {
        $this->opacidade_fundo = $opacidade_fundo;
    }

    public function getSem_navegacao() {
        return $this->sem_navegacao;
    }

    public function setSem_navegacao($sem_navegacao) {
        $this->sem_navegacao = $sem_navegacao;
    }

    public function getCor_links() {
        return $this->cor_links;
    }

    public function setCor_links($cor_links) {
        $this->cor_links = $cor_links;
    }

    public function getEstilo_links() {
        return $this->estilo_links;
    }

    public function setEstilo_links($estilo_links) {
        $this->estilo_links = $estilo_links;
    }

    public function getLinks() {
        return $this->links;
    }

    public function setLinks($links) {
        $this->links = $links;
    }

    public function getTexto_pagina() {
        return $this->texto_pagina;
    }

    public function setTexto_pagina($texto_pagina) {
        $this->texto_pagina = $texto_pagina;
    }

    public function getNome_imagem() {
        return $this->nome_imagem;
    }

    public function setNome_imagem($nome_imagem) {
        $this->nome_imagem = $nome_imagem;
    }

    public function getUrl_imagem() {
        return $this->url_imagem;
    }

    public function setUrl_imagem($url_imagem) {
        $this->url_imagem = $url_imagem;
    }

    public function getLargura_imagem() {
        return $this->largura_imagem;
    }

    public function setLargura_imagem($largura_imagem) {
        $this->largura_imagem = $largura_imagem;
    }

    public function getAlt_imagem() {
        return $this->alt_imagem;
    }

    public function setAlt_imagem($alt_imagem) {
        $this->alt_imagem = $alt_imagem;
    }

    public function getAlt_text_imagem() {
        return $this->alt_text_imagem;
    }

    public function setAlt_text_imagem($alt_text_imagem) {
        $this->alt_text_imagem = $alt_text_imagem;
    }

    public function getIncluir_lista() {
        return $this->incluir_lista;
    }

    public function setIncluir_lista($incluir_lista) {
        $this->incluir_lista = $incluir_lista;
    }

    public function getIncluir_tabela() {
        return $this->incluir_tabela;
    }

    public function setIncluir_tabela($incluir_tabela) {
        $this->incluir_tabela = $incluir_tabela;
    }

    public function getIncluir_rodape() {
        return $this->incluir_rodape;
    }

    public function setIncluir_rodape($incluir_rodape) {
        $this->incluir_rodape = $incluir_rodape;
    }

    public function getIncluir_card() {
        return $this->incluir_card;
    }

    public function setIncluir_card($incluir_card) {
        $this->incluir_card = $incluir_card;
    }

    public function getIncluir_formulario() {
        return $this->incluir_formulario;
    }

    public function setIncluir_formulario($incluir_formulario) {
        $this->incluir_formulario = $incluir_formulario;
    }

    public function getTexto_botao() {
        return $this->texto_botao;
    }

    public function setTexto_botao($texto_botao) {
        $this->texto_botao = $texto_botao;
    }

    public function getLink_botao() {
        return $this->link_botao;
    }

    public function setLink_botao($link_botao) {
        $this->link_botao = $link_botao;
    }

    public function getCor_botao() {
        return $this->cor_botao;
    }

    public function setCor_botao($cor_botao) {
        $this->cor_botao = $cor_botao;
    }

    public function getCor_botao_hover() {
        return $this->cor_botao_hover;
    }

    public function setCor_botao_hover($cor_botao_hover) {
        $this->cor_botao_hover = $cor_botao_hover;
    }

    public function getOrdem_elementos() {
        return $this->ordem_elementos;
    }

    public function setOrdem_elementos($ordem_elementos) {
        $this->ordem_elementos = $ordem_elementos;
    }

    public function getCss_customizado() {
        return $this->css_customizado;
    }

    public function setCss_customizado($css_customizado) {
        $this->css_customizado = $css_customizado;
    }

    public function getHtml_customizado() {
        return $this->html_customizado;
    }

    public function setHtml_customizado($html_customizado) {
        $this->html_customizado = $html_customizado;
    }

}