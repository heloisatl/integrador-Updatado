<?php

namespace app\models;

class Banco {
    private $id_banco;
    private $fk_usuario;
    private $nome_banco;
    private $usuario_banco;
    private $senha_banco;
    private $host;
    private $porta;

    public function getId_banco() {
        return $this->id_banco;
    }

    public function setId_banco($id_banco) {
        $this->id_banco = $id_banco;
    }

    public function getFk_usuario() {
        return $this->fk_usuario;
    }

    public function setFk_usuario($fk_usuario) {
        $this->fk_usuario = $fk_usuario;
    }

    public function getNome_banco() {
        return $this->nome_banco;
    }

    public function setNome_banco($nome_banco) {
        $this->nome_banco = $nome_banco;
    }

    public function getUsuario_banco() {
        return $this->usuario_banco;
    }

    public function setUsuario_banco($usuario_banco) {
        $this->usuario_banco = $usuario_banco;
    }

    public function getSenha_banco() {
        return $this->senha_banco;
    }

    public function setSenha_banco($senha_banco) {
        $this->senha_banco = $senha_banco;
    }

    public function getHost() {
        return $this->host;
    }

    public function setHost($host) {
        $this->host = $host;
    }

    public function getPorta() {
        return $this->porta;
    }

    public function setPorta($porta) {
        $this->porta = $porta;
    }

}