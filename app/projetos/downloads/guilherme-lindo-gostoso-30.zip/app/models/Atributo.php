<?php

namespace app\models;

class Atributo {
    private $id_atributo;
    private $fk_tabela;
    private $fk_atributo;
    private $nome_atributo;
    private $tipo;
    private $PK;
    private $NN;
    private $AI;
    private $UQ;

    public function getId_atributo() {
        return $this->id_atributo;
    }

    public function setId_atributo($id_atributo) {
        $this->id_atributo = $id_atributo;
    }

    public function getFk_tabela() {
        return $this->fk_tabela;
    }

    public function setFk_tabela($fk_tabela) {
        $this->fk_tabela = $fk_tabela;
    }

    public function getFk_atributo() {
        return $this->fk_atributo;
    }

    public function setFk_atributo($fk_atributo) {
        $this->fk_atributo = $fk_atributo;
    }

    public function getNome_atributo() {
        return $this->nome_atributo;
    }

    public function setNome_atributo($nome_atributo) {
        $this->nome_atributo = $nome_atributo;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function getPK() {
        return $this->PK;
    }

    public function setPK($PK) {
        $this->PK = $PK;
    }

    public function getNN() {
        return $this->NN;
    }

    public function setNN($NN) {
        $this->NN = $NN;
    }

    public function getAI() {
        return $this->AI;
    }

    public function setAI($AI) {
        $this->AI = $AI;
    }

    public function getUQ() {
        return $this->UQ;
    }

    public function setUQ($UQ) {
        $this->UQ = $UQ;
    }

}