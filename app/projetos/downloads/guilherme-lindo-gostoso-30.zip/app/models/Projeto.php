<?php

namespace app\models;

class Projeto {
    private $id_projeto;
    private $id_usuario;
    private $fk_banco;
    private $fk_estilo;
    private $ultimo_download;
    private $nome_projeto;
    private $data_criacao;
    private $prazo_de_vida;
    private $caminho_armazenamento;
    private $comentarios;
    private $views;

    public function getId_projeto() {
        return $this->id_projeto;
    }

    public function setId_projeto($id_projeto) {
        $this->id_projeto = $id_projeto;
    }

    public function getId_usuario() {
        return $this->id_usuario;
    }

    public function setId_usuario($id_usuario) {
        $this->id_usuario = $id_usuario;
    }

    public function getFk_banco() {
        return $this->fk_banco;
    }

    public function setFk_banco($fk_banco) {
        $this->fk_banco = $fk_banco;
    }

    public function getFk_estilo() {
        return $this->fk_estilo;
    }

    public function setFk_estilo($fk_estilo) {
        $this->fk_estilo = $fk_estilo;
    }

    public function getUltimo_download() {
        return $this->ultimo_download;
    }

    public function setUltimo_download($ultimo_download) {
        $this->ultimo_download = $ultimo_download;
    }

    public function getNome_projeto() {
        return $this->nome_projeto;
    }

    public function setNome_projeto($nome_projeto) {
        $this->nome_projeto = $nome_projeto;
    }

    public function getData_criacao() {
        return $this->data_criacao;
    }

    public function setData_criacao($data_criacao) {
        $this->data_criacao = $data_criacao;
    }

    public function getPrazo_de_vida() {
        return $this->prazo_de_vida;
    }

    public function setPrazo_de_vida($prazo_de_vida) {
        $this->prazo_de_vida = $prazo_de_vida;
    }

    public function getCaminho_armazenamento() {
        return $this->caminho_armazenamento;
    }

    public function setCaminho_armazenamento($caminho_armazenamento) {
        $this->caminho_armazenamento = $caminho_armazenamento;
    }

    public function getComentarios() {
        return $this->comentarios;
    }

    public function setComentarios($comentarios) {
        $this->comentarios = $comentarios;
    }

    public function getViews() {
        return $this->views;
    }

    public function setViews($views) {
        $this->views = $views;
    }

}