<?php

namespace app\models;

class Usuario {
    private $id_usuario;
    private $email;
    private $senha_usuario;
    private $tipo_perfil;
    private $nome;

    public function getId_usuario() {
        return $this->id_usuario;
    }

    public function setId_usuario($id_usuario) {
        $this->id_usuario = $id_usuario;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function getSenha_usuario() {
        return $this->senha_usuario;
    }

    public function setSenha_usuario($senha_usuario) {
        $this->senha_usuario = $senha_usuario;
    }

    public function getTipo_perfil() {
        return $this->tipo_perfil;
    }

    public function setTipo_perfil($tipo_perfil) {
        $this->tipo_perfil = $tipo_perfil;
    }

    public function getNome() {
        return $this->nome;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

}