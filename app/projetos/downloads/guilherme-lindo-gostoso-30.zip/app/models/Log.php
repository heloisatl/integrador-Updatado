<?php

namespace app\models;

class Log {
    private $id_log;
    private $acao;
    private $data;
    private $fk_usuario;

    public function getId_log() {
        return $this->id_log;
    }

    public function setId_log($id_log) {
        $this->id_log = $id_log;
    }

    public function getAcao() {
        return $this->acao;
    }

    public function setAcao($acao) {
        $this->acao = $acao;
    }

    public function getData() {
        return $this->data;
    }

    public function setData($data) {
        $this->data = $data;
    }

    public function getFk_usuario() {
        return $this->fk_usuario;
    }

    public function setFk_usuario($fk_usuario) {
        $this->fk_usuario = $fk_usuario;
    }

}