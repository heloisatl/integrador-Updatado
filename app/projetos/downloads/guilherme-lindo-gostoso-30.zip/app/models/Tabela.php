<?php

namespace app\models;

class Tabela {
    private $id_tabela;
    private $nome_tabela;
    private $fk_banco;

    public function getId_tabela() {
        return $this->id_tabela;
    }

    public function setId_tabela($id_tabela) {
        $this->id_tabela = $id_tabela;
    }

    public function getNome_tabela() {
        return $this->nome_tabela;
    }

    public function setNome_tabela($nome_tabela) {
        $this->nome_tabela = $nome_tabela;
    }

    public function getFk_banco() {
        return $this->fk_banco;
    }

    public function setFk_banco($fk_banco) {
        $this->fk_banco = $fk_banco;
    }

}