<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Projeto;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Projeto
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'projeto':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class ProjetoRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Projeto $obj): bool {
        $sql = "INSERT INTO projeto (id_usuario, fk_banco, fk_estilo, ultimo_download, nome_projeto, data_criacao, prazo_de_vida, caminho_armazenamento, comentarios, views) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $id_usuario = $obj->getId_usuario();
        $fk_banco = $obj->getFk_banco();
        $fk_estilo = $obj->getFk_estilo();
        $ultimo_download = $obj->getUltimo_download();
        $nome_projeto = $obj->getNome_projeto();
        $data_criacao = $obj->getData_criacao();
        $prazo_de_vida = $obj->getPrazo_de_vida();
        $caminho_armazenamento = $obj->getCaminho_armazenamento();
        $comentarios = $obj->getComentarios();
        $views = $obj->getViews();

        return $stmt->execute([$id_usuario, $fk_banco, $fk_estilo, $ultimo_download, $nome_projeto, $data_criacao, $prazo_de_vida, $caminho_armazenamento, $comentarios, $views]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM projeto";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id_projeto').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM projeto WHERE id_projeto = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Projeto $obj, int $id): bool {
        $id_usuario = $obj->getId_usuario();
        $fk_banco = $obj->getFk_banco();
        $fk_estilo = $obj->getFk_estilo();
        $ultimo_download = $obj->getUltimo_download();
        $nome_projeto = $obj->getNome_projeto();
        $data_criacao = $obj->getData_criacao();
        $prazo_de_vida = $obj->getPrazo_de_vida();
        $caminho_armazenamento = $obj->getCaminho_armazenamento();
        $comentarios = $obj->getComentarios();
        $views = $obj->getViews();

        $sql = "UPDATE projeto SET id_usuario = ?, fk_banco = ?, fk_estilo = ?, ultimo_download = ?, nome_projeto = ?, data_criacao = ?, prazo_de_vida = ?, caminho_armazenamento = ?, comentarios = ?, views = ? WHERE id_projeto = ?";
        $params = [$id_usuario, $fk_banco, $fk_estilo, $ultimo_download, $nome_projeto, $data_criacao, $prazo_de_vida, $caminho_armazenamento, $comentarios, $views, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM projeto WHERE id_projeto = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}