<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Estilo;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Estilo
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'estilo':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class EstiloRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Estilo $obj): bool {
        $sql = "INSERT INTO estilo (nome_arquivo, texto_cabecalho, titulo_aba, cor_fundo, cor_fonte, tamanho_fonte, tipo_layout, alinhamento_horizontal, alinhamento_vertical, margem_pagina, preenchimento_pagina, cabecalho_fixo, url_fonte, peso_fonte, altura_linha, raio_borda, tipo_sombra, imagem_fundo, cor_gradiente_inicial, cor_gradiente_final, opacidade_fundo, sem_navegacao, cor_links, estilo_links, links, texto_pagina, nome_imagem, url_imagem, largura_imagem, alt_imagem, alt_text_imagem, incluir_lista, incluir_tabela, incluir_rodape, incluir_card, incluir_formulario, texto_botao, link_botao, cor_botao, cor_botao_hover, ordem_elementos, css_customizado, html_customizado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $nome_arquivo = $obj->getNome_arquivo();
        $texto_cabecalho = $obj->getTexto_cabecalho();
        $titulo_aba = $obj->getTitulo_aba();
        $cor_fundo = $obj->getCor_fundo();
        $cor_fonte = $obj->getCor_fonte();
        $tamanho_fonte = $obj->getTamanho_fonte();
        $tipo_layout = $obj->getTipo_layout();
        $alinhamento_horizontal = $obj->getAlinhamento_horizontal();
        $alinhamento_vertical = $obj->getAlinhamento_vertical();
        $margem_pagina = $obj->getMargem_pagina();
        $preenchimento_pagina = $obj->getPreenchimento_pagina();
        $cabecalho_fixo = $obj->getCabecalho_fixo();
        $url_fonte = $obj->getUrl_fonte();
        $peso_fonte = $obj->getPeso_fonte();
        $altura_linha = $obj->getAltura_linha();
        $raio_borda = $obj->getRaio_borda();
        $tipo_sombra = $obj->getTipo_sombra();
        $imagem_fundo = $obj->getImagem_fundo();
        $cor_gradiente_inicial = $obj->getCor_gradiente_inicial();
        $cor_gradiente_final = $obj->getCor_gradiente_final();
        $opacidade_fundo = $obj->getOpacidade_fundo();
        $sem_navegacao = $obj->getSem_navegacao();
        $cor_links = $obj->getCor_links();
        $estilo_links = $obj->getEstilo_links();
        $links = $obj->getLinks();
        $texto_pagina = $obj->getTexto_pagina();
        $nome_imagem = $obj->getNome_imagem();
        $url_imagem = $obj->getUrl_imagem();
        $largura_imagem = $obj->getLargura_imagem();
        $alt_imagem = $obj->getAlt_imagem();
        $alt_text_imagem = $obj->getAlt_text_imagem();
        $incluir_lista = $obj->getIncluir_lista();
        $incluir_tabela = $obj->getIncluir_tabela();
        $incluir_rodape = $obj->getIncluir_rodape();
        $incluir_card = $obj->getIncluir_card();
        $incluir_formulario = $obj->getIncluir_formulario();
        $texto_botao = $obj->getTexto_botao();
        $link_botao = $obj->getLink_botao();
        $cor_botao = $obj->getCor_botao();
        $cor_botao_hover = $obj->getCor_botao_hover();
        $ordem_elementos = $obj->getOrdem_elementos();
        $css_customizado = $obj->getCss_customizado();
        $html_customizado = $obj->getHtml_customizado();

        return $stmt->execute([$nome_arquivo, $texto_cabecalho, $titulo_aba, $cor_fundo, $cor_fonte, $tamanho_fonte, $tipo_layout, $alinhamento_horizontal, $alinhamento_vertical, $margem_pagina, $preenchimento_pagina, $cabecalho_fixo, $url_fonte, $peso_fonte, $altura_linha, $raio_borda, $tipo_sombra, $imagem_fundo, $cor_gradiente_inicial, $cor_gradiente_final, $opacidade_fundo, $sem_navegacao, $cor_links, $estilo_links, $links, $texto_pagina, $nome_imagem, $url_imagem, $largura_imagem, $alt_imagem, $alt_text_imagem, $incluir_lista, $incluir_tabela, $incluir_rodape, $incluir_card, $incluir_formulario, $texto_botao, $link_botao, $cor_botao, $cor_botao_hover, $ordem_elementos, $css_customizado, $html_customizado]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM estilo";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id_estilo').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM estilo WHERE id_estilo = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Estilo $obj, int $id): bool {
        $nome_arquivo = $obj->getNome_arquivo();
        $texto_cabecalho = $obj->getTexto_cabecalho();
        $titulo_aba = $obj->getTitulo_aba();
        $cor_fundo = $obj->getCor_fundo();
        $cor_fonte = $obj->getCor_fonte();
        $tamanho_fonte = $obj->getTamanho_fonte();
        $tipo_layout = $obj->getTipo_layout();
        $alinhamento_horizontal = $obj->getAlinhamento_horizontal();
        $alinhamento_vertical = $obj->getAlinhamento_vertical();
        $margem_pagina = $obj->getMargem_pagina();
        $preenchimento_pagina = $obj->getPreenchimento_pagina();
        $cabecalho_fixo = $obj->getCabecalho_fixo();
        $url_fonte = $obj->getUrl_fonte();
        $peso_fonte = $obj->getPeso_fonte();
        $altura_linha = $obj->getAltura_linha();
        $raio_borda = $obj->getRaio_borda();
        $tipo_sombra = $obj->getTipo_sombra();
        $imagem_fundo = $obj->getImagem_fundo();
        $cor_gradiente_inicial = $obj->getCor_gradiente_inicial();
        $cor_gradiente_final = $obj->getCor_gradiente_final();
        $opacidade_fundo = $obj->getOpacidade_fundo();
        $sem_navegacao = $obj->getSem_navegacao();
        $cor_links = $obj->getCor_links();
        $estilo_links = $obj->getEstilo_links();
        $links = $obj->getLinks();
        $texto_pagina = $obj->getTexto_pagina();
        $nome_imagem = $obj->getNome_imagem();
        $url_imagem = $obj->getUrl_imagem();
        $largura_imagem = $obj->getLargura_imagem();
        $alt_imagem = $obj->getAlt_imagem();
        $alt_text_imagem = $obj->getAlt_text_imagem();
        $incluir_lista = $obj->getIncluir_lista();
        $incluir_tabela = $obj->getIncluir_tabela();
        $incluir_rodape = $obj->getIncluir_rodape();
        $incluir_card = $obj->getIncluir_card();
        $incluir_formulario = $obj->getIncluir_formulario();
        $texto_botao = $obj->getTexto_botao();
        $link_botao = $obj->getLink_botao();
        $cor_botao = $obj->getCor_botao();
        $cor_botao_hover = $obj->getCor_botao_hover();
        $ordem_elementos = $obj->getOrdem_elementos();
        $css_customizado = $obj->getCss_customizado();
        $html_customizado = $obj->getHtml_customizado();

        $sql = "UPDATE estilo SET nome_arquivo = ?, texto_cabecalho = ?, titulo_aba = ?, cor_fundo = ?, cor_fonte = ?, tamanho_fonte = ?, tipo_layout = ?, alinhamento_horizontal = ?, alinhamento_vertical = ?, margem_pagina = ?, preenchimento_pagina = ?, cabecalho_fixo = ?, url_fonte = ?, peso_fonte = ?, altura_linha = ?, raio_borda = ?, tipo_sombra = ?, imagem_fundo = ?, cor_gradiente_inicial = ?, cor_gradiente_final = ?, opacidade_fundo = ?, sem_navegacao = ?, cor_links = ?, estilo_links = ?, links = ?, texto_pagina = ?, nome_imagem = ?, url_imagem = ?, largura_imagem = ?, alt_imagem = ?, alt_text_imagem = ?, incluir_lista = ?, incluir_tabela = ?, incluir_rodape = ?, incluir_card = ?, incluir_formulario = ?, texto_botao = ?, link_botao = ?, cor_botao = ?, cor_botao_hover = ?, ordem_elementos = ?, css_customizado = ?, html_customizado = ? WHERE id_estilo = ?";
        $params = [$nome_arquivo, $texto_cabecalho, $titulo_aba, $cor_fundo, $cor_fonte, $tamanho_fonte, $tipo_layout, $alinhamento_horizontal, $alinhamento_vertical, $margem_pagina, $preenchimento_pagina, $cabecalho_fixo, $url_fonte, $peso_fonte, $altura_linha, $raio_borda, $tipo_sombra, $imagem_fundo, $cor_gradiente_inicial, $cor_gradiente_final, $opacidade_fundo, $sem_navegacao, $cor_links, $estilo_links, $links, $texto_pagina, $nome_imagem, $url_imagem, $largura_imagem, $alt_imagem, $alt_text_imagem, $incluir_lista, $incluir_tabela, $incluir_rodape, $incluir_card, $incluir_formulario, $texto_botao, $link_botao, $cor_botao, $cor_botao_hover, $ordem_elementos, $css_customizado, $html_customizado, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM estilo WHERE id_estilo = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}