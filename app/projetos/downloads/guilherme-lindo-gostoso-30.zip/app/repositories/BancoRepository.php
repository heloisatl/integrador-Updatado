<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Banco;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Banco
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'banco':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class BancoRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Banco $obj): bool {
        $sql = "INSERT INTO banco (fk_usuario, nome_banco, usuario_banco, senha_banco, host, porta) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $fk_usuario = $obj->getFk_usuario();
        $nome_banco = $obj->getNome_banco();
        $usuario_banco = $obj->getUsuario_banco();
        $senha_banco = $obj->getSenha_banco();
        $host = $obj->getHost();
        $porta = $obj->getPorta();

        return $stmt->execute([$fk_usuario, $nome_banco, $usuario_banco, $senha_banco, $host, $porta]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM banco";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id_banco').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM banco WHERE id_banco = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Banco $obj, int $id): bool {
        $fk_usuario = $obj->getFk_usuario();
        $nome_banco = $obj->getNome_banco();
        $usuario_banco = $obj->getUsuario_banco();
        $senha_banco = $obj->getSenha_banco();
        $host = $obj->getHost();
        $porta = $obj->getPorta();

        $sql = "UPDATE banco SET fk_usuario = ?, nome_banco = ?, usuario_banco = ?, senha_banco = ?, host = ?, porta = ? WHERE id_banco = ?";
        $params = [$fk_usuario, $nome_banco, $usuario_banco, $senha_banco, $host, $porta, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM banco WHERE id_banco = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}