<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Atributo;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Atributo
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'atributo':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class AtributoRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Atributo $obj): bool {
        $sql = "INSERT INTO atributo (fk_tabela, fk_atributo, nome_atributo, tipo, PK, NN, AI, UQ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $fk_tabela = $obj->getFk_tabela();
        $fk_atributo = $obj->getFk_atributo();
        $nome_atributo = $obj->getNome_atributo();
        $tipo = $obj->getTipo();
        $PK = $obj->getPK();
        $NN = $obj->getNN();
        $AI = $obj->getAI();
        $UQ = $obj->getUQ();

        return $stmt->execute([$fk_tabela, $fk_atributo, $nome_atributo, $tipo, $PK, $NN, $AI, $UQ]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM atributo";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id_atributo').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM atributo WHERE id_atributo = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Atributo $obj, int $id): bool {
        $fk_tabela = $obj->getFk_tabela();
        $fk_atributo = $obj->getFk_atributo();
        $nome_atributo = $obj->getNome_atributo();
        $tipo = $obj->getTipo();
        $PK = $obj->getPK();
        $NN = $obj->getNN();
        $AI = $obj->getAI();
        $UQ = $obj->getUQ();

        $sql = "UPDATE atributo SET fk_tabela = ?, fk_atributo = ?, nome_atributo = ?, tipo = ?, PK = ?, NN = ?, AI = ?, UQ = ? WHERE id_atributo = ?";
        $params = [$fk_tabela, $fk_atributo, $nome_atributo, $tipo, $PK, $NN, $AI, $UQ, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM atributo WHERE id_atributo = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}