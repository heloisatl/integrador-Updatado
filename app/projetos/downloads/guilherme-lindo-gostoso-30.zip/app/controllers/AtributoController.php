<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Atributo;
use app\services\AtributoService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (AtributoService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class AtributoController extends Controller {
    private AtributoService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (AtributoService).
     */
    public function __construct() {
        $this->repository = new AtributoService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (atributos/index).
     */
    public function index(): void {
        $data['atributos'] = $this->repository->listarTodos();
        $this->view('atributos/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('atributos/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Atributo e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $atributo = new Atributo();
        $atributo->setFk_tabela($_POST['fk_tabela'] ?? '');
        $atributo->setFk_atributo($_POST['fk_atributo'] ?? '');
        $atributo->setNome_atributo($_POST['nome_atributo'] ?? '');
        $atributo->setTipo($_POST['tipo'] ?? '');
        $atributo->setPK($_POST['PK'] ?? '');
        $atributo->setNN($_POST['NN'] ?? '');
        $atributo->setAI($_POST['AI'] ?? '');
        $atributo->setUQ($_POST['UQ'] ?? '');

        if ($this->repository->inserir($atributo)) {
            $this->redirect(URL_BASE . '/atributos');
        } else {
            $data['erro'] = 'Erro ao cadastrar atributo.';
            $this->view('atributos/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['atributo'] = $this->repository->buscarPorId($id);

        if (!$data['atributo']) {
            $this->redirect(URL_BASE . '/atributos');
        }

        $this->view('atributos/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Atributo e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/atributos');
        }

        $id = (int) $_POST['id'];
        $atributo = new Atributo();
        $atributo->setFk_tabela($_POST['fk_tabela'] ?? '');
        $atributo->setFk_atributo($_POST['fk_atributo'] ?? '');
        $atributo->setNome_atributo($_POST['nome_atributo'] ?? '');
        $atributo->setTipo($_POST['tipo'] ?? '');
        $atributo->setPK($_POST['PK'] ?? '');
        $atributo->setNN($_POST['NN'] ?? '');
        $atributo->setAI($_POST['AI'] ?? '');
        $atributo->setUQ($_POST['UQ'] ?? '');

        if ($this->repository->alterar($atributo, $id)) {
            $this->redirect(URL_BASE . '/atributos');
        } else {
            $this->redirect(URL_BASE . '/atributos/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/atributos');
    }
}