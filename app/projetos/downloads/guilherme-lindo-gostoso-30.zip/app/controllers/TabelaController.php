<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Tabela;
use app\services\TabelaService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (TabelaService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class TabelaController extends Controller {
    private TabelaService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (TabelaService).
     */
    public function __construct() {
        $this->repository = new TabelaService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (tabelas/index).
     */
    public function index(): void {
        $data['tabelas'] = $this->repository->listarTodos();
        $this->view('tabelas/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('tabelas/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Tabela e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $tabela = new Tabela();
        $tabela->setNome_tabela($_POST['nome_tabela'] ?? '');
        $tabela->setFk_banco($_POST['fk_banco'] ?? '');

        if ($this->repository->inserir($tabela)) {
            $this->redirect(URL_BASE . '/tabelas');
        } else {
            $data['erro'] = 'Erro ao cadastrar tabela.';
            $this->view('tabelas/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['tabela'] = $this->repository->buscarPorId($id);

        if (!$data['tabela']) {
            $this->redirect(URL_BASE . '/tabelas');
        }

        $this->view('tabelas/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Tabela e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/tabelas');
        }

        $id = (int) $_POST['id'];
        $tabela = new Tabela();
        $tabela->setNome_tabela($_POST['nome_tabela'] ?? '');
        $tabela->setFk_banco($_POST['fk_banco'] ?? '');

        if ($this->repository->alterar($tabela, $id)) {
            $this->redirect(URL_BASE . '/tabelas');
        } else {
            $this->redirect(URL_BASE . '/tabelas/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/tabelas');
    }
}