<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Banco;
use app\services\BancoService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (BancoService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class BancoController extends Controller {
    private BancoService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (BancoService).
     */
    public function __construct() {
        $this->repository = new BancoService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (bancos/index).
     */
    public function index(): void {
        $data['bancos'] = $this->repository->listarTodos();
        $this->view('bancos/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('bancos/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Banco e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $banco = new Banco();
        $banco->setFk_usuario($_POST['fk_usuario'] ?? '');
        $banco->setNome_banco($_POST['nome_banco'] ?? '');
        $banco->setUsuario_banco($_POST['usuario_banco'] ?? '');
        $banco->setSenha_banco($_POST['senha_banco'] ?? '');
        $banco->setHost($_POST['host'] ?? '');
        $banco->setPorta($_POST['porta'] ?? '');

        if ($this->repository->inserir($banco)) {
            $this->redirect(URL_BASE . '/bancos');
        } else {
            $data['erro'] = 'Erro ao cadastrar banco.';
            $this->view('bancos/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['banco'] = $this->repository->buscarPorId($id);

        if (!$data['banco']) {
            $this->redirect(URL_BASE . '/bancos');
        }

        $this->view('bancos/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Banco e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/bancos');
        }

        $id = (int) $_POST['id'];
        $banco = new Banco();
        $banco->setFk_usuario($_POST['fk_usuario'] ?? '');
        $banco->setNome_banco($_POST['nome_banco'] ?? '');
        $banco->setUsuario_banco($_POST['usuario_banco'] ?? '');
        $banco->setSenha_banco($_POST['senha_banco'] ?? '');
        $banco->setHost($_POST['host'] ?? '');
        $banco->setPorta($_POST['porta'] ?? '');

        if ($this->repository->alterar($banco, $id)) {
            $this->redirect(URL_BASE . '/bancos');
        } else {
            $this->redirect(URL_BASE . '/bancos/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/bancos');
    }
}