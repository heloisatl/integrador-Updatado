<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Log;
use app\services\LogService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (LogService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class LogController extends Controller {
    private LogService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (LogService).
     */
    public function __construct() {
        $this->repository = new LogService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (logs/index).
     */
    public function index(): void {
        $data['logs'] = $this->repository->listarTodos();
        $this->view('logs/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('logs/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Log e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $log = new Log();
        $log->setAcao($_POST['acao'] ?? '');
        $log->setData($_POST['data'] ?? '');
        $log->setFk_usuario($_POST['fk_usuario'] ?? '');

        if ($this->repository->inserir($log)) {
            $this->redirect(URL_BASE . '/logs');
        } else {
            $data['erro'] = 'Erro ao cadastrar log.';
            $this->view('logs/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['log'] = $this->repository->buscarPorId($id);

        if (!$data['log']) {
            $this->redirect(URL_BASE . '/logs');
        }

        $this->view('logs/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Log e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/logs');
        }

        $id = (int) $_POST['id'];
        $log = new Log();
        $log->setAcao($_POST['acao'] ?? '');
        $log->setData($_POST['data'] ?? '');
        $log->setFk_usuario($_POST['fk_usuario'] ?? '');

        if ($this->repository->alterar($log, $id)) {
            $this->redirect(URL_BASE . '/logs');
        } else {
            $this->redirect(URL_BASE . '/logs/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/logs');
    }
}