<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Usuario;
use app\services\UsuarioService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (UsuarioService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class UsuarioController extends Controller {
    private UsuarioService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (UsuarioService).
     */
    public function __construct() {
        $this->repository = new UsuarioService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (usuarios/index).
     */
    public function index(): void {
        $data['usuarios'] = $this->repository->listarTodos();
        $this->view('usuarios/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('usuarios/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Usuario e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $usuario = new Usuario();
        $usuario->setEmail($_POST['email'] ?? '');
        $usuario->setSenha_usuario($_POST['senha_usuario'] ?? '');
        $usuario->setTipo_perfil($_POST['tipo_perfil'] ?? '');
        $usuario->setNome($_POST['nome'] ?? '');

        if ($this->repository->inserir($usuario)) {
            $this->redirect(URL_BASE . '/usuarios');
        } else {
            $data['erro'] = 'Erro ao cadastrar usuario.';
            $this->view('usuarios/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['usuario'] = $this->repository->buscarPorId($id);

        if (!$data['usuario']) {
            $this->redirect(URL_BASE . '/usuarios');
        }

        $this->view('usuarios/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Usuario e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/usuarios');
        }

        $id = (int) $_POST['id'];
        $usuario = new Usuario();
        $usuario->setEmail($_POST['email'] ?? '');
        $usuario->setSenha_usuario($_POST['senha_usuario'] ?? '');
        $usuario->setTipo_perfil($_POST['tipo_perfil'] ?? '');
        $usuario->setNome($_POST['nome'] ?? '');

        if ($this->repository->alterar($usuario, $id)) {
            $this->redirect(URL_BASE . '/usuarios');
        } else {
            $this->redirect(URL_BASE . '/usuarios/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/usuarios');
    }
}