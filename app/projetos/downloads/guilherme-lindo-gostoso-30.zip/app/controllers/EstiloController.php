<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Estilo;
use app\services\EstiloService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (EstiloService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class EstiloController extends Controller {
    private EstiloService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (EstiloService).
     */
    public function __construct() {
        $this->repository = new EstiloService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (estilos/index).
     */
    public function index(): void {
        $data['estilos'] = $this->repository->listarTodos();
        $this->view('estilos/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('estilos/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Estilo e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $estilo = new Estilo();
        $estilo->setNome_arquivo($_POST['nome_arquivo'] ?? '');
        $estilo->setTexto_cabecalho($_POST['texto_cabecalho'] ?? '');
        $estilo->setTitulo_aba($_POST['titulo_aba'] ?? '');
        $estilo->setCor_fundo($_POST['cor_fundo'] ?? '');
        $estilo->setCor_fonte($_POST['cor_fonte'] ?? '');
        $estilo->setTamanho_fonte($_POST['tamanho_fonte'] ?? '');
        $estilo->setTipo_layout($_POST['tipo_layout'] ?? '');
        $estilo->setAlinhamento_horizontal($_POST['alinhamento_horizontal'] ?? '');
        $estilo->setAlinhamento_vertical($_POST['alinhamento_vertical'] ?? '');
        $estilo->setMargem_pagina($_POST['margem_pagina'] ?? '');
        $estilo->setPreenchimento_pagina($_POST['preenchimento_pagina'] ?? '');
        $estilo->setCabecalho_fixo($_POST['cabecalho_fixo'] ?? '');
        $estilo->setUrl_fonte($_POST['url_fonte'] ?? '');
        $estilo->setPeso_fonte($_POST['peso_fonte'] ?? '');
        $estilo->setAltura_linha($_POST['altura_linha'] ?? '');
        $estilo->setRaio_borda($_POST['raio_borda'] ?? '');
        $estilo->setTipo_sombra($_POST['tipo_sombra'] ?? '');
        $estilo->setImagem_fundo($_POST['imagem_fundo'] ?? '');
        $estilo->setCor_gradiente_inicial($_POST['cor_gradiente_inicial'] ?? '');
        $estilo->setCor_gradiente_final($_POST['cor_gradiente_final'] ?? '');
        $estilo->setOpacidade_fundo($_POST['opacidade_fundo'] ?? '');
        $estilo->setSem_navegacao($_POST['sem_navegacao'] ?? '');
        $estilo->setCor_links($_POST['cor_links'] ?? '');
        $estilo->setEstilo_links($_POST['estilo_links'] ?? '');
        $estilo->setLinks($_POST['links'] ?? '');
        $estilo->setTexto_pagina($_POST['texto_pagina'] ?? '');
        $estilo->setNome_imagem($_POST['nome_imagem'] ?? '');
        $estilo->setUrl_imagem($_POST['url_imagem'] ?? '');
        $estilo->setLargura_imagem($_POST['largura_imagem'] ?? '');
        $estilo->setAlt_imagem($_POST['alt_imagem'] ?? '');
        $estilo->setAlt_text_imagem($_POST['alt_text_imagem'] ?? '');
        $estilo->setIncluir_lista($_POST['incluir_lista'] ?? '');
        $estilo->setIncluir_tabela($_POST['incluir_tabela'] ?? '');
        $estilo->setIncluir_rodape($_POST['incluir_rodape'] ?? '');
        $estilo->setIncluir_card($_POST['incluir_card'] ?? '');
        $estilo->setIncluir_formulario($_POST['incluir_formulario'] ?? '');
        $estilo->setTexto_botao($_POST['texto_botao'] ?? '');
        $estilo->setLink_botao($_POST['link_botao'] ?? '');
        $estilo->setCor_botao($_POST['cor_botao'] ?? '');
        $estilo->setCor_botao_hover($_POST['cor_botao_hover'] ?? '');
        $estilo->setOrdem_elementos($_POST['ordem_elementos'] ?? '');
        $estilo->setCss_customizado($_POST['css_customizado'] ?? '');
        $estilo->setHtml_customizado($_POST['html_customizado'] ?? '');

        if ($this->repository->inserir($estilo)) {
            $this->redirect(URL_BASE . '/estilos');
        } else {
            $data['erro'] = 'Erro ao cadastrar estilo.';
            $this->view('estilos/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['estilo'] = $this->repository->buscarPorId($id);

        if (!$data['estilo']) {
            $this->redirect(URL_BASE . '/estilos');
        }

        $this->view('estilos/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Estilo e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/estilos');
        }

        $id = (int) $_POST['id'];
        $estilo = new Estilo();
        $estilo->setNome_arquivo($_POST['nome_arquivo'] ?? '');
        $estilo->setTexto_cabecalho($_POST['texto_cabecalho'] ?? '');
        $estilo->setTitulo_aba($_POST['titulo_aba'] ?? '');
        $estilo->setCor_fundo($_POST['cor_fundo'] ?? '');
        $estilo->setCor_fonte($_POST['cor_fonte'] ?? '');
        $estilo->setTamanho_fonte($_POST['tamanho_fonte'] ?? '');
        $estilo->setTipo_layout($_POST['tipo_layout'] ?? '');
        $estilo->setAlinhamento_horizontal($_POST['alinhamento_horizontal'] ?? '');
        $estilo->setAlinhamento_vertical($_POST['alinhamento_vertical'] ?? '');
        $estilo->setMargem_pagina($_POST['margem_pagina'] ?? '');
        $estilo->setPreenchimento_pagina($_POST['preenchimento_pagina'] ?? '');
        $estilo->setCabecalho_fixo($_POST['cabecalho_fixo'] ?? '');
        $estilo->setUrl_fonte($_POST['url_fonte'] ?? '');
        $estilo->setPeso_fonte($_POST['peso_fonte'] ?? '');
        $estilo->setAltura_linha($_POST['altura_linha'] ?? '');
        $estilo->setRaio_borda($_POST['raio_borda'] ?? '');
        $estilo->setTipo_sombra($_POST['tipo_sombra'] ?? '');
        $estilo->setImagem_fundo($_POST['imagem_fundo'] ?? '');
        $estilo->setCor_gradiente_inicial($_POST['cor_gradiente_inicial'] ?? '');
        $estilo->setCor_gradiente_final($_POST['cor_gradiente_final'] ?? '');
        $estilo->setOpacidade_fundo($_POST['opacidade_fundo'] ?? '');
        $estilo->setSem_navegacao($_POST['sem_navegacao'] ?? '');
        $estilo->setCor_links($_POST['cor_links'] ?? '');
        $estilo->setEstilo_links($_POST['estilo_links'] ?? '');
        $estilo->setLinks($_POST['links'] ?? '');
        $estilo->setTexto_pagina($_POST['texto_pagina'] ?? '');
        $estilo->setNome_imagem($_POST['nome_imagem'] ?? '');
        $estilo->setUrl_imagem($_POST['url_imagem'] ?? '');
        $estilo->setLargura_imagem($_POST['largura_imagem'] ?? '');
        $estilo->setAlt_imagem($_POST['alt_imagem'] ?? '');
        $estilo->setAlt_text_imagem($_POST['alt_text_imagem'] ?? '');
        $estilo->setIncluir_lista($_POST['incluir_lista'] ?? '');
        $estilo->setIncluir_tabela($_POST['incluir_tabela'] ?? '');
        $estilo->setIncluir_rodape($_POST['incluir_rodape'] ?? '');
        $estilo->setIncluir_card($_POST['incluir_card'] ?? '');
        $estilo->setIncluir_formulario($_POST['incluir_formulario'] ?? '');
        $estilo->setTexto_botao($_POST['texto_botao'] ?? '');
        $estilo->setLink_botao($_POST['link_botao'] ?? '');
        $estilo->setCor_botao($_POST['cor_botao'] ?? '');
        $estilo->setCor_botao_hover($_POST['cor_botao_hover'] ?? '');
        $estilo->setOrdem_elementos($_POST['ordem_elementos'] ?? '');
        $estilo->setCss_customizado($_POST['css_customizado'] ?? '');
        $estilo->setHtml_customizado($_POST['html_customizado'] ?? '');

        if ($this->repository->alterar($estilo, $id)) {
            $this->redirect(URL_BASE . '/estilos');
        } else {
            $this->redirect(URL_BASE . '/estilos/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/estilos');
    }
}