<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Projeto;
use app\services\ProjetoService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (ProjetoService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class ProjetoController extends Controller {
    private ProjetoService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (ProjetoService).
     */
    public function __construct() {
        $this->repository = new ProjetoService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (projetos/index).
     */
    public function index(): void {
        $data['projetos'] = $this->repository->listarTodos();
        $this->view('projetos/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('projetos/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Projeto e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $projeto = new Projeto();
        $projeto->setId_usuario($_POST['id_usuario'] ?? '');
        $projeto->setFk_banco($_POST['fk_banco'] ?? '');
        $projeto->setFk_estilo($_POST['fk_estilo'] ?? '');
        $projeto->setUltimo_download($_POST['ultimo_download'] ?? '');
        $projeto->setNome_projeto($_POST['nome_projeto'] ?? '');
        $projeto->setData_criacao($_POST['data_criacao'] ?? '');
        $projeto->setPrazo_de_vida($_POST['prazo_de_vida'] ?? '');
        $projeto->setCaminho_armazenamento($_POST['caminho_armazenamento'] ?? '');
        $projeto->setComentarios($_POST['comentarios'] ?? '');
        $projeto->setViews($_POST['views'] ?? '');

        if ($this->repository->inserir($projeto)) {
            $this->redirect(URL_BASE . '/projetos');
        } else {
            $data['erro'] = 'Erro ao cadastrar projeto.';
            $this->view('projetos/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['projeto'] = $this->repository->buscarPorId($id);

        if (!$data['projeto']) {
            $this->redirect(URL_BASE . '/projetos');
        }

        $this->view('projetos/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Projeto e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/projetos');
        }

        $id = (int) $_POST['id'];
        $projeto = new Projeto();
        $projeto->setId_usuario($_POST['id_usuario'] ?? '');
        $projeto->setFk_banco($_POST['fk_banco'] ?? '');
        $projeto->setFk_estilo($_POST['fk_estilo'] ?? '');
        $projeto->setUltimo_download($_POST['ultimo_download'] ?? '');
        $projeto->setNome_projeto($_POST['nome_projeto'] ?? '');
        $projeto->setData_criacao($_POST['data_criacao'] ?? '');
        $projeto->setPrazo_de_vida($_POST['prazo_de_vida'] ?? '');
        $projeto->setCaminho_armazenamento($_POST['caminho_armazenamento'] ?? '');
        $projeto->setComentarios($_POST['comentarios'] ?? '');
        $projeto->setViews($_POST['views'] ?? '');

        if ($this->repository->alterar($projeto, $id)) {
            $this->redirect(URL_BASE . '/projetos');
        } else {
            $this->redirect(URL_BASE . '/projetos/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/projetos');
    }
}