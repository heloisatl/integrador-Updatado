

<div class="page-header">
    <h1 class="page-title">Editar Log</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/logs" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/logs/atualizar" method="POST">
<?php $obj = $log; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($log['id_log'] ?? '') ?>">
<input type='text' name='acao' id='acao' value='<?= $obj?$obj['acao']:''?>'><br>
<p><b>Erro:o tipo de atributo datetime não foi reconhecido.</b></p><input type='number' name='fk_usuario' id='fk_usuario' value='<?= $obj?$obj['fk_usuario']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>