

<div class="page-header">
    <h1 class="page-title">Editar Banco</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/bancos" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/bancos/atualizar" method="POST">
<?php $obj = $banco; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($banco['id_banco'] ?? '') ?>">
<input type='number' name='fk_usuario' id='fk_usuario' value='<?= $obj?$obj['fk_usuario']:''?>'><br>
<input type='text' name='nome_banco' id='nome_banco' value='<?= $obj?$obj['nome_banco']:''?>'><br>
<input type='text' name='usuario_banco' id='usuario_banco' value='<?= $obj?$obj['usuario_banco']:''?>'><br>
<input type='text' name='senha_banco' id='senha_banco' value='<?= $obj?$obj['senha_banco']:''?>'><br>
<input type='text' name='host' id='host' value='<?= $obj?$obj['host']:''?>'><br>
<input type='text' name='porta' id='porta' value='<?= $obj?$obj['porta']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>