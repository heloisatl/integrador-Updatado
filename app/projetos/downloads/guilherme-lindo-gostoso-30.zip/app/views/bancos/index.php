

<div class="page-header">
    <h1 class="page-title">Listagem de Banco</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/bancos/cadastrar" class="btn btn-primary">
            Novo Banco
        </a>
    </div>
</div>

<?php if (empty($bancos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/bancos/cadastrar" class="btn btn-primary">
            Criar Primeiro Banco
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id_banco</th>
                    <th>Fk_usuario</th>
                    <th>Nome_banco</th>
                    <th>Usuario_banco</th>
                    <th>Senha_banco</th>
                    <th>Host</th>
                    <th>Porta</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bancos as $banco): ?>
                    <tr>
                        <td><?= htmlspecialchars($banco['id_banco'] ?? '') ?></td>
                        <td><?= htmlspecialchars($banco['fk_usuario'] ?? '') ?></td>
                        <td><?= htmlspecialchars($banco['nome_banco'] ?? '') ?></td>
                        <td><?= htmlspecialchars($banco['usuario_banco'] ?? '') ?></td>
                        <td><?= htmlspecialchars($banco['senha_banco'] ?? '') ?></td>
                        <td><?= htmlspecialchars($banco['host'] ?? '') ?></td>
                        <td><?= htmlspecialchars($banco['porta'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/bancos/editar?id=<?= $banco['id_banco'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/bancos/excluir?id=<?= $banco['id_banco'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>