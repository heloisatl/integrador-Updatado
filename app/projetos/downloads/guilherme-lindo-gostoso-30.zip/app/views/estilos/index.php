

<div class="page-header">
    <h1 class="page-title">Listagem de Estilo</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/estilos/cadastrar" class="btn btn-primary">
            Novo Estilo
        </a>
    </div>
</div>

<?php if (empty($estilos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/estilos/cadastrar" class="btn btn-primary">
            Criar Primeiro Estilo
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id_estilo</th>
                    <th>Nome_arquivo</th>
                    <th>Texto_cabecalho</th>
                    <th>Titulo_aba</th>
                    <th>Cor_fundo</th>
                    <th>Cor_fonte</th>
                    <th>Tamanho_fonte</th>
                    <th>Tipo_layout</th>
                    <th>Alinhamento_horizontal</th>
                    <th>Alinhamento_vertical</th>
                    <th>Margem_pagina</th>
                    <th>Preenchimento_pagina</th>
                    <th>Cabecalho_fixo</th>
                    <th>Url_fonte</th>
                    <th>Peso_fonte</th>
                    <th>Altura_linha</th>
                    <th>Raio_borda</th>
                    <th>Tipo_sombra</th>
                    <th>Imagem_fundo</th>
                    <th>Cor_gradiente_inicial</th>
                    <th>Cor_gradiente_final</th>
                    <th>Opacidade_fundo</th>
                    <th>Sem_navegacao</th>
                    <th>Cor_links</th>
                    <th>Estilo_links</th>
                    <th>Links</th>
                    <th>Texto_pagina</th>
                    <th>Nome_imagem</th>
                    <th>Url_imagem</th>
                    <th>Largura_imagem</th>
                    <th>Alt_imagem</th>
                    <th>Alt_text_imagem</th>
                    <th>Incluir_lista</th>
                    <th>Incluir_tabela</th>
                    <th>Incluir_rodape</th>
                    <th>Incluir_card</th>
                    <th>Incluir_formulario</th>
                    <th>Texto_botao</th>
                    <th>Link_botao</th>
                    <th>Cor_botao</th>
                    <th>Cor_botao_hover</th>
                    <th>Ordem_elementos</th>
                    <th>Css_customizado</th>
                    <th>Html_customizado</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($estilos as $estilo): ?>
                    <tr>
                        <td><?= htmlspecialchars($estilo['id_estilo'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['nome_arquivo'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['texto_cabecalho'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['titulo_aba'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['cor_fundo'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['cor_fonte'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['tamanho_fonte'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['tipo_layout'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['alinhamento_horizontal'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['alinhamento_vertical'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['margem_pagina'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['preenchimento_pagina'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['cabecalho_fixo'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['url_fonte'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['peso_fonte'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['altura_linha'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['raio_borda'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['tipo_sombra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['imagem_fundo'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['cor_gradiente_inicial'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['cor_gradiente_final'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['opacidade_fundo'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['sem_navegacao'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['cor_links'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['estilo_links'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['links'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['texto_pagina'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['nome_imagem'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['url_imagem'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['largura_imagem'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['alt_imagem'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['alt_text_imagem'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['incluir_lista'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['incluir_tabela'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['incluir_rodape'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['incluir_card'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['incluir_formulario'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['texto_botao'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['link_botao'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['cor_botao'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['cor_botao_hover'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['ordem_elementos'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['css_customizado'] ?? '') ?></td>
                        <td><?= htmlspecialchars($estilo['html_customizado'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/estilos/editar?id=<?= $estilo['id_estilo'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/estilos/excluir?id=<?= $estilo['id_estilo'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>