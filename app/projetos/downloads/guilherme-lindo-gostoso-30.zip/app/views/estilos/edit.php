

<div class="page-header">
    <h1 class="page-title">Editar Estilo</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/estilos" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/estilos/atualizar" method="POST">
<?php $obj = $estilo; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($estilo['id_estilo'] ?? '') ?>">
<input type='text' name='nome_arquivo' id='nome_arquivo' value='<?= $obj?$obj['nome_arquivo']:''?>'><br>
<input type='text' name='texto_cabecalho' id='texto_cabecalho' value='<?= $obj?$obj['texto_cabecalho']:''?>'><br>
<input type='text' name='titulo_aba' id='titulo_aba' value='<?= $obj?$obj['titulo_aba']:''?>'><br>
<input type='text' name='cor_fundo' id='cor_fundo' value='<?= $obj?$obj['cor_fundo']:''?>'><br>
<input type='text' name='cor_fonte' id='cor_fonte' value='<?= $obj?$obj['cor_fonte']:''?>'><br>
<input type='text' name='tamanho_fonte' id='tamanho_fonte' value='<?= $obj?$obj['tamanho_fonte']:''?>'><br>
<input type='text' name='tipo_layout' id='tipo_layout' value='<?= $obj?$obj['tipo_layout']:''?>'><br>
<input type='text' name='alinhamento_horizontal' id='alinhamento_horizontal' value='<?= $obj?$obj['alinhamento_horizontal']:''?>'><br>
<input type='text' name='alinhamento_vertical' id='alinhamento_vertical' value='<?= $obj?$obj['alinhamento_vertical']:''?>'><br>
<input type='number' name='margem_pagina' id='margem_pagina' value='<?= $obj?$obj['margem_pagina']:''?>'><br>
<input type='number' name='preenchimento_pagina' id='preenchimento_pagina' value='<?= $obj?$obj['preenchimento_pagina']:''?>'><br>
<p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><input type='text' name='url_fonte' id='url_fonte' value='<?= $obj?$obj['url_fonte']:''?>'><br>
<input type='text' name='peso_fonte' id='peso_fonte' value='<?= $obj?$obj['peso_fonte']:''?>'><br>
<input type='number' step='0.01' name='altura_linha' id='altura_linha' value='<?= $obj?$obj['altura_linha']:''?>'><br>
<input type='number' name='raio_borda' id='raio_borda' value='<?= $obj?$obj['raio_borda']:''?>'><br>
<input type='text' name='tipo_sombra' id='tipo_sombra' value='<?= $obj?$obj['tipo_sombra']:''?>'><br>
<input type='text' name='imagem_fundo' id='imagem_fundo' value='<?= $obj?$obj['imagem_fundo']:''?>'><br>
<input type='text' name='cor_gradiente_inicial' id='cor_gradiente_inicial' value='<?= $obj?$obj['cor_gradiente_inicial']:''?>'><br>
<input type='text' name='cor_gradiente_final' id='cor_gradiente_final' value='<?= $obj?$obj['cor_gradiente_final']:''?>'><br>
<input type='number' name='opacidade_fundo' id='opacidade_fundo' value='<?= $obj?$obj['opacidade_fundo']:''?>'><br>
<p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><input type='text' name='cor_links' id='cor_links' value='<?= $obj?$obj['cor_links']:''?>'><br>
<p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><input type='text' name='links' id='links' value='<?= $obj?$obj['links']:''?>'><br>
<p><b>Erro:o tipo de atributo mediumtext não foi reconhecido.</b></p><input type='text' name='nome_imagem' id='nome_imagem' value='<?= $obj?$obj['nome_imagem']:''?>'><br>
<input type='text' name='url_imagem' id='url_imagem' value='<?= $obj?$obj['url_imagem']:''?>'><br>
<input type='number' name='largura_imagem' id='largura_imagem' value='<?= $obj?$obj['largura_imagem']:''?>'><br>
<input type='text' name='alt_imagem' id='alt_imagem' value='<?= $obj?$obj['alt_imagem']:''?>'><br>
<input type='text' name='alt_text_imagem' id='alt_text_imagem' value='<?= $obj?$obj['alt_text_imagem']:''?>'><br>
<p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><input type='text' name='texto_botao' id='texto_botao' value='<?= $obj?$obj['texto_botao']:''?>'><br>
<input type='text' name='link_botao' id='link_botao' value='<?= $obj?$obj['link_botao']:''?>'><br>
<input type='text' name='cor_botao' id='cor_botao' value='<?= $obj?$obj['cor_botao']:''?>'><br>
<input type='text' name='cor_botao_hover' id='cor_botao_hover' value='<?= $obj?$obj['cor_botao_hover']:''?>'><br>
<input type='text' name='ordem_elementos' id='ordem_elementos' value='<?= $obj?$obj['ordem_elementos']:''?>'><br>
<p><b>Erro:o tipo de atributo mediumtext não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo mediumtext não foi reconhecido.</b></p>
        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>