

<div class="page-header">
    <h1 class="page-title">Editar Usuario</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/usuarios" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/usuarios/atualizar" method="POST">
<?php $obj = $usuario; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($usuario['id_usuario'] ?? '') ?>">
<input type='text' name='email' id='email' value='<?= $obj?$obj['email']:''?>'><br>
<input type='text' name='senha_usuario' id='senha_usuario' value='<?= $obj?$obj['senha_usuario']:''?>'><br>
<select name="tipo_perfil" id="tipo_perfil">
<option value=""><b>--</b></option>
<option value="admin" <?= $obj? ($obj['tipo_perfil']=='admin' ? 'selected' : null) : null ?> ><b>admin</b></option>
<option value="usuario" <?= $obj? ($obj['tipo_perfil']=='usuario' ? 'selected' : null) : null ?> ><b>usuario</b></option>
</select>
<input type='text' name='nome' id='nome' value='<?= $obj?$obj['nome']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>