

<div class="page-header">
    <h1 class="page-title">Cadastrar Usuario</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/usuarios" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/usuarios/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='email' id='email' value='<?= $obj?$obj['email']:''?>'><br>
<input type='text' name='senha_usuario' id='senha_usuario' value='<?= $obj?$obj['senha_usuario']:''?>'><br>
<select name="tipo_perfil" id="tipo_perfil">
<option value=""><b>--</b></option>
<option value="admin" <?= $obj? ($obj['tipo_perfil']=='admin' ? 'selected' : null) : null ?> ><b>admin</b></option>
<option value="usuario" <?= $obj? ($obj['tipo_perfil']=='usuario' ? 'selected' : null) : null ?> ><b>usuario</b></option>
</select>
<input type='text' name='nome' id='nome' value='<?= $obj?$obj['nome']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>