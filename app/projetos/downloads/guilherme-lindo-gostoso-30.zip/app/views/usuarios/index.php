

<div class="page-header">
    <h1 class="page-title">Listagem de Usuario</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/usuarios/cadastrar" class="btn btn-primary">
            Novo Usuario
        </a>
    </div>
</div>

<?php if (empty($usuarios)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/usuarios/cadastrar" class="btn btn-primary">
            Criar Primeiro Usuario
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id_usuario</th>
                    <th>Email</th>
                    <th>Senha_usuario</th>
                    <th>Tipo_perfil</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td><?= htmlspecialchars($usuario['id_usuario'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuario['email'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuario['senha_usuario'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuario['tipo_perfil'] ?? '') ?></td>
                        <td><?= htmlspecialchars($usuario['nome'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/usuarios/editar?id=<?= $usuario['id_usuario'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/usuarios/excluir?id=<?= $usuario['id_usuario'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>