

<div class="page-header">
    <h1 class="page-title">Listagem de Projeto</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/projetos/cadastrar" class="btn btn-primary">
            Novo Projeto
        </a>
    </div>
</div>

<?php if (empty($projetos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/projetos/cadastrar" class="btn btn-primary">
            Criar Primeiro Projeto
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id_projeto</th>
                    <th>Id_usuario</th>
                    <th>Fk_banco</th>
                    <th>Fk_estilo</th>
                    <th>Ultimo_download</th>
                    <th>Nome_projeto</th>
                    <th>Data_criacao</th>
                    <th>Prazo_de_vida</th>
                    <th>Caminho_armazenamento</th>
                    <th>Comentarios</th>
                    <th>Views</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($projetos as $projeto): ?>
                    <tr>
                        <td><?= htmlspecialchars($projeto['id_projeto'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['id_usuario'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['fk_banco'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['fk_estilo'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['ultimo_download'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['nome_projeto'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['data_criacao'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['prazo_de_vida'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['caminho_armazenamento'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['comentarios'] ?? '') ?></td>
                        <td><?= htmlspecialchars($projeto['views'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/projetos/editar?id=<?= $projeto['id_projeto'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/projetos/excluir?id=<?= $projeto['id_projeto'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>