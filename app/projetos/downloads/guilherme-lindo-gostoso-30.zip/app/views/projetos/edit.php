

<div class="page-header">
    <h1 class="page-title">Editar Projeto</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/projetos" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/projetos/atualizar" method="POST">
<?php $obj = $projeto; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($projeto['id_projeto'] ?? '') ?>">
<input type='number' name='id_usuario' id='id_usuario' value='<?= $obj?$obj['id_usuario']:''?>'><br>
<input type='number' name='fk_banco' id='fk_banco' value='<?= $obj?$obj['fk_banco']:''?>'><br>
<input type='number' name='fk_estilo' id='fk_estilo' value='<?= $obj?$obj['fk_estilo']:''?>'><br>
<input type='number' name='ultimo_download' id='ultimo_download' value='<?= $obj?$obj['ultimo_download']:''?>'><br>
<input type='text' name='nome_projeto' id='nome_projeto' value='<?= $obj?$obj['nome_projeto']:''?>'><br>
<p><b>Erro:o tipo de atributo datetime não foi reconhecido.</b></p><input type='number' name='prazo_de_vida' id='prazo_de_vida' value='<?= $obj?$obj['prazo_de_vida']:''?>'><br>
<input type='text' name='caminho_armazenamento' id='caminho_armazenamento' value='<?= $obj?$obj['caminho_armazenamento']:''?>'><br>
<p><b>Erro:o tipo de atributo tinyint(4) não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo tinyint(4) não foi reconhecido.</b></p>
        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>