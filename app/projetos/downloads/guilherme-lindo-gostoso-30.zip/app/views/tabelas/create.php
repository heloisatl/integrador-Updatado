

<div class="page-header">
    <h1 class="page-title">Cadastrar Tabela</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/tabelas" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/tabelas/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='nome_tabela' id='nome_tabela' value='<?= $obj?$obj['nome_tabela']:''?>'><br>
<input type='number' name='fk_banco' id='fk_banco' value='<?= $obj?$obj['fk_banco']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>