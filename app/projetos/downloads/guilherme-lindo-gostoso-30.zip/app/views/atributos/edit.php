

<div class="page-header">
    <h1 class="page-title">Editar Atributo</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/atributos" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/atributos/atualizar" method="POST">
<?php $obj = $atributo; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($atributo['id_atributo'] ?? '') ?>">
<input type='number' name='fk_tabela' id='fk_tabela' value='<?= $obj?$obj['fk_tabela']:''?>'><br>
<input type='number' name='fk_atributo' id='fk_atributo' value='<?= $obj?$obj['fk_atributo']:''?>'><br>
<input type='text' name='nome_atributo' id='nome_atributo' value='<?= $obj?$obj['nome_atributo']:''?>'><br>
<p><b>Erro:o tipo de atributo tinytext não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo tinyint(4) não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo tinyint(4) não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo tinyint(4) não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo tinyint(4) não foi reconhecido.</b></p>
        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>