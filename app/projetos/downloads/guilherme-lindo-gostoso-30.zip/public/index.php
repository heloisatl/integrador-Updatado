<?php

/**
 * Ponto de Entrada Único (Front Controller) - Arquitetura MVC
 *
 * No padrão Front Controller, TODAS as requisições HTTP da aplicação passam por este arquivo (index.php):
 * 
 * 1. INICIALIZAÇÃO E AMBIENTE:
 *    - Configura diretivas de tratamento e exibição de erros (error_reporting / display_errors);
 *    - Carrega as definições globais de ambiente e credenciais do banco (config.php).
 *
 * 2. AUTOLOADING (Compatível com PSR-4):
 *    - O Autoload.php registra o carregamento automático via spl_autoload_register,
 *      instanciando Controllers, Models e Repositories sob demanda sem requires manuais.
 *
 * 3. ROTEAMENTO (Router):
 *    - Mapeia URLs e verbos HTTP (GET / POST) para o Controller e Método correspondentes;
 *    - Ao final, $router->run() inspeciona a URL atual e despacha a execução da ação solicitada.
 */

use app\core\Router;

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../app/core/Autoload.php';
require_once __DIR__ . '/../app/config/config.php';

$router = new Router();

// Mapeamento das Rotas RESTful da Aplicação:
$router->get('/', 'AtributoController@index');
$router->get('/atributos', 'AtributoController@index');
$router->get('/atributos/cadastrar', 'AtributoController@cadastrar');
$router->post('/atributos/salvar', 'AtributoController@salvar');
$router->get('/atributos/editar', 'AtributoController@editar');
$router->post('/atributos/atualizar', 'AtributoController@atualizar');
$router->get('/atributos/excluir', 'AtributoController@excluir');

$router->get('/bancos', 'BancoController@index');
$router->get('/bancos/cadastrar', 'BancoController@cadastrar');
$router->post('/bancos/salvar', 'BancoController@salvar');
$router->get('/bancos/editar', 'BancoController@editar');
$router->post('/bancos/atualizar', 'BancoController@atualizar');
$router->get('/bancos/excluir', 'BancoController@excluir');

$router->get('/estilos', 'EstiloController@index');
$router->get('/estilos/cadastrar', 'EstiloController@cadastrar');
$router->post('/estilos/salvar', 'EstiloController@salvar');
$router->get('/estilos/editar', 'EstiloController@editar');
$router->post('/estilos/atualizar', 'EstiloController@atualizar');
$router->get('/estilos/excluir', 'EstiloController@excluir');

$router->get('/logs', 'LogController@index');
$router->get('/logs/cadastrar', 'LogController@cadastrar');
$router->post('/logs/salvar', 'LogController@salvar');
$router->get('/logs/editar', 'LogController@editar');
$router->post('/logs/atualizar', 'LogController@atualizar');
$router->get('/logs/excluir', 'LogController@excluir');

$router->get('/projetos', 'ProjetoController@index');
$router->get('/projetos/cadastrar', 'ProjetoController@cadastrar');
$router->post('/projetos/salvar', 'ProjetoController@salvar');
$router->get('/projetos/editar', 'ProjetoController@editar');
$router->post('/projetos/atualizar', 'ProjetoController@atualizar');
$router->get('/projetos/excluir', 'ProjetoController@excluir');

$router->get('/tabelas', 'TabelaController@index');
$router->get('/tabelas/cadastrar', 'TabelaController@cadastrar');
$router->post('/tabelas/salvar', 'TabelaController@salvar');
$router->get('/tabelas/editar', 'TabelaController@editar');
$router->post('/tabelas/atualizar', 'TabelaController@atualizar');
$router->get('/tabelas/excluir', 'TabelaController@excluir');

$router->get('/usuarios', 'UsuarioController@index');
$router->get('/usuarios/cadastrar', 'UsuarioController@cadastrar');
$router->post('/usuarios/salvar', 'UsuarioController@salvar');
$router->get('/usuarios/editar', 'UsuarioController@editar');
$router->post('/usuarios/atualizar', 'UsuarioController@atualizar');
$router->get('/usuarios/excluir', 'UsuarioController@excluir');

// Despacha a requisição de acordo com o método HTTP e URI solicitada
$router->run();
