-- Script gerado automaticamente pelo DevStudio (MVC Creator)
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8mb4;
USE `phpmyadmin`;

CREATE TABLE IF NOT EXISTS `pma__bookmark` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `dbase` varchar(255) NOT NULL,
    `user` varchar(255) NOT NULL,
    `label` varchar(255) NOT NULL,
    `query` text NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__central_columns` (
    `db_name` varchar(64) NOT NULL,
    `col_name` varchar(64) NOT NULL,
    `col_type` varchar(64) NOT NULL,
    `col_length` text,
    `col_collation` varchar(64) NOT NULL,
    `col_isNull` tinyint(1) NOT NULL,
    `col_extra` varchar(255),
    `col_default` text,
    PRIMARY KEY (`db_name`, `col_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__column_info` (
    `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
    `db_name` varchar(64) NOT NULL UNIQUE,
    `table_name` varchar(64) NOT NULL UNIQUE,
    `column_name` varchar(64) NOT NULL UNIQUE,
    `comment` varchar(255) NOT NULL,
    `mimetype` varchar(255) NOT NULL,
    `transformation` varchar(255) NOT NULL,
    `transformation_options` varchar(255) NOT NULL,
    `input_transformation` varchar(255) NOT NULL,
    `input_transformation_options` varchar(255) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__designer_settings` (
    `username` varchar(64) NOT NULL,
    `settings_data` text NOT NULL,
    PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__export_templates` (
    `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
    `username` varchar(64) NOT NULL UNIQUE,
    `export_type` varchar(10) NOT NULL UNIQUE,
    `template_name` varchar(64) NOT NULL UNIQUE,
    `template_data` text NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__favorite` (
    `username` varchar(64) NOT NULL,
    `tables` text NOT NULL,
    PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__history` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `username` varchar(64) NOT NULL,
    `db` varchar(64) NOT NULL,
    `table` varchar(64) NOT NULL,
    `timevalue` timestamp NOT NULL,
    `sqlquery` text NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__navigationhiding` (
    `username` varchar(64) NOT NULL,
    `item_name` varchar(64) NOT NULL,
    `item_type` varchar(64) NOT NULL,
    `db_name` varchar(64) NOT NULL,
    `table_name` varchar(64) NOT NULL,
    PRIMARY KEY (`username`, `item_name`, `item_type`, `db_name`, `table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__pdf_pages` (
    `db_name` varchar(64) NOT NULL,
    `page_nr` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `page_descr` varchar(50) NOT NULL,
    PRIMARY KEY (`page_nr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__recent` (
    `username` varchar(64) NOT NULL,
    `tables` text NOT NULL,
    PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__relation` (
    `master_db` varchar(64) NOT NULL,
    `master_table` varchar(64) NOT NULL,
    `master_field` varchar(64) NOT NULL,
    `foreign_db` varchar(64) NOT NULL,
    `foreign_table` varchar(64) NOT NULL,
    `foreign_field` varchar(64) NOT NULL,
    PRIMARY KEY (`master_db`, `master_table`, `master_field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__savedsearches` (
    `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
    `username` varchar(64) NOT NULL UNIQUE,
    `db_name` varchar(64) NOT NULL UNIQUE,
    `search_name` varchar(64) NOT NULL UNIQUE,
    `search_data` text NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__table_coords` (
    `db_name` varchar(64) NOT NULL,
    `table_name` varchar(64) NOT NULL,
    `pdf_page_number` int(11) NOT NULL,
    `x` float unsigned NOT NULL,
    `y` float unsigned NOT NULL,
    PRIMARY KEY (`db_name`, `table_name`, `pdf_page_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__table_info` (
    `db_name` varchar(64) NOT NULL,
    `table_name` varchar(64) NOT NULL,
    `display_field` varchar(64) NOT NULL,
    PRIMARY KEY (`db_name`, `table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__table_uiprefs` (
    `username` varchar(64) NOT NULL,
    `db_name` varchar(64) NOT NULL,
    `table_name` varchar(64) NOT NULL,
    `prefs` text NOT NULL,
    `last_update` timestamp NOT NULL,
    PRIMARY KEY (`username`, `db_name`, `table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__tracking` (
    `db_name` varchar(64) NOT NULL,
    `table_name` varchar(64) NOT NULL,
    `version` int(10) unsigned NOT NULL,
    `date_created` datetime NOT NULL,
    `date_updated` datetime NOT NULL,
    `schema_snapshot` text NOT NULL,
    `schema_sql` text,
    `data_sql` longtext,
    `tracking` set('update','replace','insert','delete','truncate','create database','alter database','drop database','create table','alter table','rename table','drop table','create index','drop index','create view','alter view','drop view'),
    `tracking_active` int(1) unsigned NOT NULL,
    PRIMARY KEY (`db_name`, `table_name`, `version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__userconfig` (
    `username` varchar(64) NOT NULL,
    `timevalue` timestamp NOT NULL,
    `config_data` text NOT NULL,
    PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__usergroups` (
    `usergroup` varchar(64) NOT NULL,
    `tab` varchar(64) NOT NULL,
    `allowed` enum('y','n') NOT NULL,
    PRIMARY KEY (`usergroup`, `tab`, `allowed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pma__users` (
    `username` varchar(64) NOT NULL,
    `usergroup` varchar(64) NOT NULL,
    PRIMARY KEY (`username`, `usergroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

