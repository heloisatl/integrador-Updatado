<?php

/**
 * Ponto de Entrada Único (Front Controller) - Arquitetura MVC
 *
 * No padrão Front Controller, TODAS as requisições HTTP da aplicação passam por este arquivo (index.php):
 * 
 * 1. INICIALIZAÇÃO E AMBIENTE:
 *    - Configura diretivas de tratamento e exibição de erros (error_reporting / display_errors);
 *    - Carrega as definições globais de ambiente e credenciais do banco (config.php).
 *
 * 2. AUTOLOADING (Compatível com PSR-4):
 *    - O Autoload.php registra o carregamento automático via spl_autoload_register,
 *      instanciando Controllers, Models e Repositories sob demanda sem requires manuais.
 *
 * 3. ROTEAMENTO (Router):
 *    - Mapeia URLs e verbos HTTP (GET / POST) para o Controller e Método correspondentes;
 *    - Ao final, $router->run() inspeciona a URL atual e despacha a execução da ação solicitada.
 */

use app\core\Router;

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../app/core/Autoload.php';
require_once __DIR__ . '/../app/config/config.php';

$router = new Router();

// Mapeamento das Rotas RESTful da Aplicação:
$router->get('/', 'Pma__bookmarkController@index');
$router->get('/pma__bookmarks', 'Pma__bookmarkController@index');
$router->get('/pma__bookmarks/cadastrar', 'Pma__bookmarkController@cadastrar');
$router->post('/pma__bookmarks/salvar', 'Pma__bookmarkController@salvar');
$router->get('/pma__bookmarks/editar', 'Pma__bookmarkController@editar');
$router->post('/pma__bookmarks/atualizar', 'Pma__bookmarkController@atualizar');
$router->get('/pma__bookmarks/excluir', 'Pma__bookmarkController@excluir');

$router->get('/pma__central_columnss', 'Pma__central_columnsController@index');
$router->get('/pma__central_columnss/cadastrar', 'Pma__central_columnsController@cadastrar');
$router->post('/pma__central_columnss/salvar', 'Pma__central_columnsController@salvar');
$router->get('/pma__central_columnss/editar', 'Pma__central_columnsController@editar');
$router->post('/pma__central_columnss/atualizar', 'Pma__central_columnsController@atualizar');
$router->get('/pma__central_columnss/excluir', 'Pma__central_columnsController@excluir');

$router->get('/pma__column_infos', 'Pma__column_infoController@index');
$router->get('/pma__column_infos/cadastrar', 'Pma__column_infoController@cadastrar');
$router->post('/pma__column_infos/salvar', 'Pma__column_infoController@salvar');
$router->get('/pma__column_infos/editar', 'Pma__column_infoController@editar');
$router->post('/pma__column_infos/atualizar', 'Pma__column_infoController@atualizar');
$router->get('/pma__column_infos/excluir', 'Pma__column_infoController@excluir');

$router->get('/pma__designer_settingss', 'Pma__designer_settingsController@index');
$router->get('/pma__designer_settingss/cadastrar', 'Pma__designer_settingsController@cadastrar');
$router->post('/pma__designer_settingss/salvar', 'Pma__designer_settingsController@salvar');
$router->get('/pma__designer_settingss/editar', 'Pma__designer_settingsController@editar');
$router->post('/pma__designer_settingss/atualizar', 'Pma__designer_settingsController@atualizar');
$router->get('/pma__designer_settingss/excluir', 'Pma__designer_settingsController@excluir');

$router->get('/pma__export_templatess', 'Pma__export_templatesController@index');
$router->get('/pma__export_templatess/cadastrar', 'Pma__export_templatesController@cadastrar');
$router->post('/pma__export_templatess/salvar', 'Pma__export_templatesController@salvar');
$router->get('/pma__export_templatess/editar', 'Pma__export_templatesController@editar');
$router->post('/pma__export_templatess/atualizar', 'Pma__export_templatesController@atualizar');
$router->get('/pma__export_templatess/excluir', 'Pma__export_templatesController@excluir');

$router->get('/pma__favorites', 'Pma__favoriteController@index');
$router->get('/pma__favorites/cadastrar', 'Pma__favoriteController@cadastrar');
$router->post('/pma__favorites/salvar', 'Pma__favoriteController@salvar');
$router->get('/pma__favorites/editar', 'Pma__favoriteController@editar');
$router->post('/pma__favorites/atualizar', 'Pma__favoriteController@atualizar');
$router->get('/pma__favorites/excluir', 'Pma__favoriteController@excluir');

$router->get('/pma__historys', 'Pma__historyController@index');
$router->get('/pma__historys/cadastrar', 'Pma__historyController@cadastrar');
$router->post('/pma__historys/salvar', 'Pma__historyController@salvar');
$router->get('/pma__historys/editar', 'Pma__historyController@editar');
$router->post('/pma__historys/atualizar', 'Pma__historyController@atualizar');
$router->get('/pma__historys/excluir', 'Pma__historyController@excluir');

$router->get('/pma__navigationhidings', 'Pma__navigationhidingController@index');
$router->get('/pma__navigationhidings/cadastrar', 'Pma__navigationhidingController@cadastrar');
$router->post('/pma__navigationhidings/salvar', 'Pma__navigationhidingController@salvar');
$router->get('/pma__navigationhidings/editar', 'Pma__navigationhidingController@editar');
$router->post('/pma__navigationhidings/atualizar', 'Pma__navigationhidingController@atualizar');
$router->get('/pma__navigationhidings/excluir', 'Pma__navigationhidingController@excluir');

$router->get('/pma__pdf_pagess', 'Pma__pdf_pagesController@index');
$router->get('/pma__pdf_pagess/cadastrar', 'Pma__pdf_pagesController@cadastrar');
$router->post('/pma__pdf_pagess/salvar', 'Pma__pdf_pagesController@salvar');
$router->get('/pma__pdf_pagess/editar', 'Pma__pdf_pagesController@editar');
$router->post('/pma__pdf_pagess/atualizar', 'Pma__pdf_pagesController@atualizar');
$router->get('/pma__pdf_pagess/excluir', 'Pma__pdf_pagesController@excluir');

$router->get('/pma__recents', 'Pma__recentController@index');
$router->get('/pma__recents/cadastrar', 'Pma__recentController@cadastrar');
$router->post('/pma__recents/salvar', 'Pma__recentController@salvar');
$router->get('/pma__recents/editar', 'Pma__recentController@editar');
$router->post('/pma__recents/atualizar', 'Pma__recentController@atualizar');
$router->get('/pma__recents/excluir', 'Pma__recentController@excluir');

$router->get('/pma__relations', 'Pma__relationController@index');
$router->get('/pma__relations/cadastrar', 'Pma__relationController@cadastrar');
$router->post('/pma__relations/salvar', 'Pma__relationController@salvar');
$router->get('/pma__relations/editar', 'Pma__relationController@editar');
$router->post('/pma__relations/atualizar', 'Pma__relationController@atualizar');
$router->get('/pma__relations/excluir', 'Pma__relationController@excluir');

$router->get('/pma__savedsearchess', 'Pma__savedsearchesController@index');
$router->get('/pma__savedsearchess/cadastrar', 'Pma__savedsearchesController@cadastrar');
$router->post('/pma__savedsearchess/salvar', 'Pma__savedsearchesController@salvar');
$router->get('/pma__savedsearchess/editar', 'Pma__savedsearchesController@editar');
$router->post('/pma__savedsearchess/atualizar', 'Pma__savedsearchesController@atualizar');
$router->get('/pma__savedsearchess/excluir', 'Pma__savedsearchesController@excluir');

$router->get('/pma__table_coordss', 'Pma__table_coordsController@index');
$router->get('/pma__table_coordss/cadastrar', 'Pma__table_coordsController@cadastrar');
$router->post('/pma__table_coordss/salvar', 'Pma__table_coordsController@salvar');
$router->get('/pma__table_coordss/editar', 'Pma__table_coordsController@editar');
$router->post('/pma__table_coordss/atualizar', 'Pma__table_coordsController@atualizar');
$router->get('/pma__table_coordss/excluir', 'Pma__table_coordsController@excluir');

$router->get('/pma__table_infos', 'Pma__table_infoController@index');
$router->get('/pma__table_infos/cadastrar', 'Pma__table_infoController@cadastrar');
$router->post('/pma__table_infos/salvar', 'Pma__table_infoController@salvar');
$router->get('/pma__table_infos/editar', 'Pma__table_infoController@editar');
$router->post('/pma__table_infos/atualizar', 'Pma__table_infoController@atualizar');
$router->get('/pma__table_infos/excluir', 'Pma__table_infoController@excluir');

$router->get('/pma__table_uiprefss', 'Pma__table_uiprefsController@index');
$router->get('/pma__table_uiprefss/cadastrar', 'Pma__table_uiprefsController@cadastrar');
$router->post('/pma__table_uiprefss/salvar', 'Pma__table_uiprefsController@salvar');
$router->get('/pma__table_uiprefss/editar', 'Pma__table_uiprefsController@editar');
$router->post('/pma__table_uiprefss/atualizar', 'Pma__table_uiprefsController@atualizar');
$router->get('/pma__table_uiprefss/excluir', 'Pma__table_uiprefsController@excluir');

$router->get('/pma__trackings', 'Pma__trackingController@index');
$router->get('/pma__trackings/cadastrar', 'Pma__trackingController@cadastrar');
$router->post('/pma__trackings/salvar', 'Pma__trackingController@salvar');
$router->get('/pma__trackings/editar', 'Pma__trackingController@editar');
$router->post('/pma__trackings/atualizar', 'Pma__trackingController@atualizar');
$router->get('/pma__trackings/excluir', 'Pma__trackingController@excluir');

$router->get('/pma__userconfigs', 'Pma__userconfigController@index');
$router->get('/pma__userconfigs/cadastrar', 'Pma__userconfigController@cadastrar');
$router->post('/pma__userconfigs/salvar', 'Pma__userconfigController@salvar');
$router->get('/pma__userconfigs/editar', 'Pma__userconfigController@editar');
$router->post('/pma__userconfigs/atualizar', 'Pma__userconfigController@atualizar');
$router->get('/pma__userconfigs/excluir', 'Pma__userconfigController@excluir');

$router->get('/pma__usergroupss', 'Pma__usergroupsController@index');
$router->get('/pma__usergroupss/cadastrar', 'Pma__usergroupsController@cadastrar');
$router->post('/pma__usergroupss/salvar', 'Pma__usergroupsController@salvar');
$router->get('/pma__usergroupss/editar', 'Pma__usergroupsController@editar');
$router->post('/pma__usergroupss/atualizar', 'Pma__usergroupsController@atualizar');
$router->get('/pma__usergroupss/excluir', 'Pma__usergroupsController@excluir');

$router->get('/pma__userss', 'Pma__usersController@index');
$router->get('/pma__userss/cadastrar', 'Pma__usersController@cadastrar');
$router->post('/pma__userss/salvar', 'Pma__usersController@salvar');
$router->get('/pma__userss/editar', 'Pma__usersController@editar');
$router->post('/pma__userss/atualizar', 'Pma__usersController@atualizar');
$router->get('/pma__userss/excluir', 'Pma__usersController@excluir');

// Despacha a requisição de acordo com o método HTTP e URI solicitada
$router->run();
