<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__userconfig;
use app\services\Pma__userconfigService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__userconfigService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__userconfigController extends Controller {
    private Pma__userconfigService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__userconfigService).
     */
    public function __construct() {
        $this->repository = new Pma__userconfigService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__userconfigs/index).
     */
    public function index(): void {
        $data['pma__userconfigs'] = $this->repository->listarTodos();
        $this->view('pma__userconfigs/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__userconfigs/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__userconfig e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__userconfig = new Pma__userconfig();
        $pma__userconfig->setTimevalue($_POST['timevalue'] ?? '');
        $pma__userconfig->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->inserir($pma__userconfig)) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__userconfig.';
            $this->view('pma__userconfigs/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__userconfig'] = $this->repository->buscarPorId($id);

        if (!$data['pma__userconfig']) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        }

        $this->view('pma__userconfigs/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__userconfig e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        }

        $id = (int) $_POST['id'];
        $pma__userconfig = new Pma__userconfig();
        $pma__userconfig->setTimevalue($_POST['timevalue'] ?? '');
        $pma__userconfig->setConfig_data($_POST['config_data'] ?? '');

        if ($this->repository->alterar($pma__userconfig, $id)) {
            $this->redirect(URL_BASE . '/pma__userconfigs');
        } else {
            $this->redirect(URL_BASE . '/pma__userconfigs/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__userconfigs');
    }
}