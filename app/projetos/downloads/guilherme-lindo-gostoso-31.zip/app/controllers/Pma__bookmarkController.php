<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__bookmark;
use app\services\Pma__bookmarkService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__bookmarkService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__bookmarkController extends Controller {
    private Pma__bookmarkService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__bookmarkService).
     */
    public function __construct() {
        $this->repository = new Pma__bookmarkService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__bookmarks/index).
     */
    public function index(): void {
        $data['pma__bookmarks'] = $this->repository->listarTodos();
        $this->view('pma__bookmarks/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__bookmarks/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__bookmark e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__bookmark = new Pma__bookmark();
        $pma__bookmark->setDbase($_POST['dbase'] ?? '');
        $pma__bookmark->setUser($_POST['user'] ?? '');
        $pma__bookmark->setLabel($_POST['label'] ?? '');
        $pma__bookmark->setQuery($_POST['query'] ?? '');

        if ($this->repository->inserir($pma__bookmark)) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__bookmark.';
            $this->view('pma__bookmarks/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__bookmark'] = $this->repository->buscarPorId($id);

        if (!$data['pma__bookmark']) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        }

        $this->view('pma__bookmarks/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__bookmark e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        }

        $id = (int) $_POST['id'];
        $pma__bookmark = new Pma__bookmark();
        $pma__bookmark->setDbase($_POST['dbase'] ?? '');
        $pma__bookmark->setUser($_POST['user'] ?? '');
        $pma__bookmark->setLabel($_POST['label'] ?? '');
        $pma__bookmark->setQuery($_POST['query'] ?? '');

        if ($this->repository->alterar($pma__bookmark, $id)) {
            $this->redirect(URL_BASE . '/pma__bookmarks');
        } else {
            $this->redirect(URL_BASE . '/pma__bookmarks/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__bookmarks');
    }
}