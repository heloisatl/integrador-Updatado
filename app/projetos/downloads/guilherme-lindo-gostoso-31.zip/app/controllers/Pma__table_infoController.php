<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__table_info;
use app\services\Pma__table_infoService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__table_infoService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__table_infoController extends Controller {
    private Pma__table_infoService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__table_infoService).
     */
    public function __construct() {
        $this->repository = new Pma__table_infoService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__table_infos/index).
     */
    public function index(): void {
        $data['pma__table_infos'] = $this->repository->listarTodos();
        $this->view('pma__table_infos/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__table_infos/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__table_info e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__table_info = new Pma__table_info();
        $pma__table_info->setDisplay_field($_POST['display_field'] ?? '');

        if ($this->repository->inserir($pma__table_info)) {
            $this->redirect(URL_BASE . '/pma__table_infos');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__table_info.';
            $this->view('pma__table_infos/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__table_info'] = $this->repository->buscarPorId($id);

        if (!$data['pma__table_info']) {
            $this->redirect(URL_BASE . '/pma__table_infos');
        }

        $this->view('pma__table_infos/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__table_info e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__table_infos');
        }

        $id = (int) $_POST['id'];
        $pma__table_info = new Pma__table_info();
        $pma__table_info->setDisplay_field($_POST['display_field'] ?? '');

        if ($this->repository->alterar($pma__table_info, $id)) {
            $this->redirect(URL_BASE . '/pma__table_infos');
        } else {
            $this->redirect(URL_BASE . '/pma__table_infos/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__table_infos');
    }
}