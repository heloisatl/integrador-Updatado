<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__pdf_pages;
use app\services\Pma__pdf_pagesService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__pdf_pagesService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__pdf_pagesController extends Controller {
    private Pma__pdf_pagesService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__pdf_pagesService).
     */
    public function __construct() {
        $this->repository = new Pma__pdf_pagesService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__pdf_pagess/index).
     */
    public function index(): void {
        $data['pma__pdf_pagess'] = $this->repository->listarTodos();
        $this->view('pma__pdf_pagess/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__pdf_pagess/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__pdf_pages e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__pdf_pages = new Pma__pdf_pages();
        $pma__pdf_pages->setDb_name($_POST['db_name'] ?? '');
        $pma__pdf_pages->setPage_descr($_POST['page_descr'] ?? '');

        if ($this->repository->inserir($pma__pdf_pages)) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__pdf_pages.';
            $this->view('pma__pdf_pagess/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__pdf_pages'] = $this->repository->buscarPorId($id);

        if (!$data['pma__pdf_pages']) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        }

        $this->view('pma__pdf_pagess/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__pdf_pages e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        }

        $id = (int) $_POST['id'];
        $pma__pdf_pages = new Pma__pdf_pages();
        $pma__pdf_pages->setDb_name($_POST['db_name'] ?? '');
        $pma__pdf_pages->setPage_descr($_POST['page_descr'] ?? '');

        if ($this->repository->alterar($pma__pdf_pages, $id)) {
            $this->redirect(URL_BASE . '/pma__pdf_pagess');
        } else {
            $this->redirect(URL_BASE . '/pma__pdf_pagess/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__pdf_pagess');
    }
}