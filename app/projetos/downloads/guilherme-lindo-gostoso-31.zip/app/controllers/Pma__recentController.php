<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__recent;
use app\services\Pma__recentService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__recentService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__recentController extends Controller {
    private Pma__recentService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__recentService).
     */
    public function __construct() {
        $this->repository = new Pma__recentService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__recents/index).
     */
    public function index(): void {
        $data['pma__recents'] = $this->repository->listarTodos();
        $this->view('pma__recents/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__recents/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__recent e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__recent = new Pma__recent();
        $pma__recent->setTables($_POST['tables'] ?? '');

        if ($this->repository->inserir($pma__recent)) {
            $this->redirect(URL_BASE . '/pma__recents');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__recent.';
            $this->view('pma__recents/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__recent'] = $this->repository->buscarPorId($id);

        if (!$data['pma__recent']) {
            $this->redirect(URL_BASE . '/pma__recents');
        }

        $this->view('pma__recents/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__recent e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__recents');
        }

        $id = (int) $_POST['id'];
        $pma__recent = new Pma__recent();
        $pma__recent->setTables($_POST['tables'] ?? '');

        if ($this->repository->alterar($pma__recent, $id)) {
            $this->redirect(URL_BASE . '/pma__recents');
        } else {
            $this->redirect(URL_BASE . '/pma__recents/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__recents');
    }
}