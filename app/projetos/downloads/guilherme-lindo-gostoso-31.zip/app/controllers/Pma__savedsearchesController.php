<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__savedsearches;
use app\services\Pma__savedsearchesService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__savedsearchesService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__savedsearchesController extends Controller {
    private Pma__savedsearchesService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__savedsearchesService).
     */
    public function __construct() {
        $this->repository = new Pma__savedsearchesService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__savedsearchess/index).
     */
    public function index(): void {
        $data['pma__savedsearchess'] = $this->repository->listarTodos();
        $this->view('pma__savedsearchess/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__savedsearchess/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__savedsearches e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__savedsearches = new Pma__savedsearches();
        $pma__savedsearches->setUsername($_POST['username'] ?? '');
        $pma__savedsearches->setDb_name($_POST['db_name'] ?? '');
        $pma__savedsearches->setSearch_name($_POST['search_name'] ?? '');
        $pma__savedsearches->setSearch_data($_POST['search_data'] ?? '');

        if ($this->repository->inserir($pma__savedsearches)) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__savedsearches.';
            $this->view('pma__savedsearchess/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__savedsearches'] = $this->repository->buscarPorId($id);

        if (!$data['pma__savedsearches']) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        }

        $this->view('pma__savedsearchess/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__savedsearches e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        }

        $id = (int) $_POST['id'];
        $pma__savedsearches = new Pma__savedsearches();
        $pma__savedsearches->setUsername($_POST['username'] ?? '');
        $pma__savedsearches->setDb_name($_POST['db_name'] ?? '');
        $pma__savedsearches->setSearch_name($_POST['search_name'] ?? '');
        $pma__savedsearches->setSearch_data($_POST['search_data'] ?? '');

        if ($this->repository->alterar($pma__savedsearches, $id)) {
            $this->redirect(URL_BASE . '/pma__savedsearchess');
        } else {
            $this->redirect(URL_BASE . '/pma__savedsearchess/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__savedsearchess');
    }
}