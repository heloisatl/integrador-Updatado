<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__designer_settings;
use app\services\Pma__designer_settingsService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__designer_settingsService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__designer_settingsController extends Controller {
    private Pma__designer_settingsService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__designer_settingsService).
     */
    public function __construct() {
        $this->repository = new Pma__designer_settingsService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__designer_settingss/index).
     */
    public function index(): void {
        $data['pma__designer_settingss'] = $this->repository->listarTodos();
        $this->view('pma__designer_settingss/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__designer_settingss/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__designer_settings e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__designer_settings = new Pma__designer_settings();
        $pma__designer_settings->setSettings_data($_POST['settings_data'] ?? '');

        if ($this->repository->inserir($pma__designer_settings)) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__designer_settings.';
            $this->view('pma__designer_settingss/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__designer_settings'] = $this->repository->buscarPorId($id);

        if (!$data['pma__designer_settings']) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        }

        $this->view('pma__designer_settingss/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__designer_settings e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        }

        $id = (int) $_POST['id'];
        $pma__designer_settings = new Pma__designer_settings();
        $pma__designer_settings->setSettings_data($_POST['settings_data'] ?? '');

        if ($this->repository->alterar($pma__designer_settings, $id)) {
            $this->redirect(URL_BASE . '/pma__designer_settingss');
        } else {
            $this->redirect(URL_BASE . '/pma__designer_settingss/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__designer_settingss');
    }
}