<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__favorite;
use app\services\Pma__favoriteService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__favoriteService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__favoriteController extends Controller {
    private Pma__favoriteService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__favoriteService).
     */
    public function __construct() {
        $this->repository = new Pma__favoriteService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__favorites/index).
     */
    public function index(): void {
        $data['pma__favorites'] = $this->repository->listarTodos();
        $this->view('pma__favorites/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__favorites/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__favorite e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__favorite = new Pma__favorite();
        $pma__favorite->setTables($_POST['tables'] ?? '');

        if ($this->repository->inserir($pma__favorite)) {
            $this->redirect(URL_BASE . '/pma__favorites');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__favorite.';
            $this->view('pma__favorites/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__favorite'] = $this->repository->buscarPorId($id);

        if (!$data['pma__favorite']) {
            $this->redirect(URL_BASE . '/pma__favorites');
        }

        $this->view('pma__favorites/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__favorite e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__favorites');
        }

        $id = (int) $_POST['id'];
        $pma__favorite = new Pma__favorite();
        $pma__favorite->setTables($_POST['tables'] ?? '');

        if ($this->repository->alterar($pma__favorite, $id)) {
            $this->redirect(URL_BASE . '/pma__favorites');
        } else {
            $this->redirect(URL_BASE . '/pma__favorites/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__favorites');
    }
}