<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__central_columns;
use app\services\Pma__central_columnsService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__central_columnsService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__central_columnsController extends Controller {
    private Pma__central_columnsService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__central_columnsService).
     */
    public function __construct() {
        $this->repository = new Pma__central_columnsService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__central_columnss/index).
     */
    public function index(): void {
        $data['pma__central_columnss'] = $this->repository->listarTodos();
        $this->view('pma__central_columnss/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__central_columnss/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__central_columns e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__central_columns = new Pma__central_columns();
        $pma__central_columns->setCol_type($_POST['col_type'] ?? '');
        $pma__central_columns->setCol_length($_POST['col_length'] ?? '');
        $pma__central_columns->setCol_collation($_POST['col_collation'] ?? '');
        $pma__central_columns->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__central_columns->setCol_extra($_POST['col_extra'] ?? '');
        $pma__central_columns->setCol_default($_POST['col_default'] ?? '');

        if ($this->repository->inserir($pma__central_columns)) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__central_columns.';
            $this->view('pma__central_columnss/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__central_columns'] = $this->repository->buscarPorId($id);

        if (!$data['pma__central_columns']) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        }

        $this->view('pma__central_columnss/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__central_columns e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        }

        $id = (int) $_POST['id'];
        $pma__central_columns = new Pma__central_columns();
        $pma__central_columns->setCol_type($_POST['col_type'] ?? '');
        $pma__central_columns->setCol_length($_POST['col_length'] ?? '');
        $pma__central_columns->setCol_collation($_POST['col_collation'] ?? '');
        $pma__central_columns->setCol_isNull($_POST['col_isNull'] ?? '');
        $pma__central_columns->setCol_extra($_POST['col_extra'] ?? '');
        $pma__central_columns->setCol_default($_POST['col_default'] ?? '');

        if ($this->repository->alterar($pma__central_columns, $id)) {
            $this->redirect(URL_BASE . '/pma__central_columnss');
        } else {
            $this->redirect(URL_BASE . '/pma__central_columnss/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__central_columnss');
    }
}