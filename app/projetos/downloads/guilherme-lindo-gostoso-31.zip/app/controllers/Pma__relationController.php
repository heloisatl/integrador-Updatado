<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Pma__relation;
use app\services\Pma__relationService;

/**
 * Camada de Controle (Controller) - Arquitetura MVC
 *
 * O Controller atua como o intermediador entre as requisições do usuário e o sistema:
 * 1. Recebe os dados enviados pelas rotas (HTTP GET / POST);
 * 2. Aciona a camada de persistência/negócio (Pma__relationService) para processar as informações;
 * 3. Prepara os dados de resposta e renderiza a View correspondente ou executa um redirecionamento.
 */
class Pma__relationController extends Controller {
    private Pma__relationService $repository;

    /**
     * Inicializa a dependência da camada de persistência/dados (Pma__relationService).
     */
    public function __construct() {
        $this->repository = new Pma__relationService();
    }

    /**
     * Listagem (GET): Recupera todos os registros e renderiza a View de listagem (pma__relations/index).
     */
    public function index(): void {
        $data['pma__relations'] = $this->repository->listarTodos();
        $this->view('pma__relations/index', $data);
    }

    /**
     * Formulário de Cadastro (GET): Exibe a View com o formulário para criação de um novo registro.
     */
    public function cadastrar(): void {
        $this->view('pma__relations/create');
    }

    /**
     * Processamento de Cadastro (POST): Recebe os dados do formulário ($_POST),
     * popula o Model Pma__relation e solicita a inserção no banco de dados.
     */
    public function salvar(): void {
        $pma__relation = new Pma__relation();
        $pma__relation->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__relation->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__relation->setForeign_field($_POST['foreign_field'] ?? '');

        if ($this->repository->inserir($pma__relation)) {
            $this->redirect(URL_BASE . '/pma__relations');
        } else {
            $data['erro'] = 'Erro ao cadastrar pma__relation.';
            $this->view('pma__relations/create', $data);
        }
    }

    /**
     * Formulário de Edição (GET): Localiza o registro existente pelo ID recebido via URL
     * e o envia preenchido para a View de edição.
     */
    public function editar(): void {
        $id = (int) ($_GET['id'] ?? 0);
        $data['pma__relation'] = $this->repository->buscarPorId($id);

        if (!$data['pma__relation']) {
            $this->redirect(URL_BASE . '/pma__relations');
        }

        $this->view('pma__relations/edit', $data);
    }

    /**
     * Processamento de Atualização (POST): Captura os dados submetidos pelo formulário,
     * atualiza as propriedades do Model Pma__relation e executa o update do registro.
     */
    public function atualizar(): void {
        if (!isset($_POST['id'])) {
            $this->redirect(URL_BASE . '/pma__relations');
        }

        $id = (int) $_POST['id'];
        $pma__relation = new Pma__relation();
        $pma__relation->setForeign_db($_POST['foreign_db'] ?? '');
        $pma__relation->setForeign_table($_POST['foreign_table'] ?? '');
        $pma__relation->setForeign_field($_POST['foreign_field'] ?? '');

        if ($this->repository->alterar($pma__relation, $id)) {
            $this->redirect(URL_BASE . '/pma__relations');
        } else {
            $this->redirect(URL_BASE . '/pma__relations/editar?id=' . $id);
        }
    }

    /**
     * Exclusão (GET): Remove com segurança o registro indicado pelo ID e retorna à listagem.
     */
    public function excluir(): void {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];
            $this->repository->excluir($id);
        }

        $this->redirect(URL_BASE . '/pma__relations');
    }
}