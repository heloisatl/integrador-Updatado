<?php

namespace app\models;

class Pma__export_templates {
    private $id;
    private $username;
    private $export_type;
    private $template_name;
    private $template_data;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getExport_type() {
        return $this->export_type;
    }

    public function setExport_type($export_type) {
        $this->export_type = $export_type;
    }

    public function getTemplate_name() {
        return $this->template_name;
    }

    public function setTemplate_name($template_name) {
        $this->template_name = $template_name;
    }

    public function getTemplate_data() {
        return $this->template_data;
    }

    public function setTemplate_data($template_data) {
        $this->template_data = $template_data;
    }

}