<?php

namespace app\models;

class Pma__table_info {
    private $db_name;
    private $table_name;
    private $display_field;

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getTable_name() {
        return $this->table_name;
    }

    public function setTable_name($table_name) {
        $this->table_name = $table_name;
    }

    public function getDisplay_field() {
        return $this->display_field;
    }

    public function setDisplay_field($display_field) {
        $this->display_field = $display_field;
    }

}