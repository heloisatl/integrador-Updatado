<?php

namespace app\models;

class Pma__tracking {
    private $db_name;
    private $table_name;
    private $version;
    private $date_created;
    private $date_updated;
    private $schema_snapshot;
    private $schema_sql;
    private $data_sql;
    private $tracking;
    private $tracking_active;

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getTable_name() {
        return $this->table_name;
    }

    public function setTable_name($table_name) {
        $this->table_name = $table_name;
    }

    public function getVersion() {
        return $this->version;
    }

    public function setVersion($version) {
        $this->version = $version;
    }

    public function getDate_created() {
        return $this->date_created;
    }

    public function setDate_created($date_created) {
        $this->date_created = $date_created;
    }

    public function getDate_updated() {
        return $this->date_updated;
    }

    public function setDate_updated($date_updated) {
        $this->date_updated = $date_updated;
    }

    public function getSchema_snapshot() {
        return $this->schema_snapshot;
    }

    public function setSchema_snapshot($schema_snapshot) {
        $this->schema_snapshot = $schema_snapshot;
    }

    public function getSchema_sql() {
        return $this->schema_sql;
    }

    public function setSchema_sql($schema_sql) {
        $this->schema_sql = $schema_sql;
    }

    public function getData_sql() {
        return $this->data_sql;
    }

    public function setData_sql($data_sql) {
        $this->data_sql = $data_sql;
    }

    public function getTracking() {
        return $this->tracking;
    }

    public function setTracking($tracking) {
        $this->tracking = $tracking;
    }

    public function getTracking_active() {
        return $this->tracking_active;
    }

    public function setTracking_active($tracking_active) {
        $this->tracking_active = $tracking_active;
    }

}