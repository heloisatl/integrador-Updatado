<?php

namespace app\models;

class Pma__table_uiprefs {
    private $username;
    private $db_name;
    private $table_name;
    private $prefs;
    private $last_update;

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getTable_name() {
        return $this->table_name;
    }

    public function setTable_name($table_name) {
        $this->table_name = $table_name;
    }

    public function getPrefs() {
        return $this->prefs;
    }

    public function setPrefs($prefs) {
        $this->prefs = $prefs;
    }

    public function getLast_update() {
        return $this->last_update;
    }

    public function setLast_update($last_update) {
        $this->last_update = $last_update;
    }

}