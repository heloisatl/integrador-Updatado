<?php

namespace app\models;

class Pma__userconfig {
    private $username;
    private $timevalue;
    private $config_data;

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getTimevalue() {
        return $this->timevalue;
    }

    public function setTimevalue($timevalue) {
        $this->timevalue = $timevalue;
    }

    public function getConfig_data() {
        return $this->config_data;
    }

    public function setConfig_data($config_data) {
        $this->config_data = $config_data;
    }

}