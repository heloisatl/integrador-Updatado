<?php

namespace app\models;

class Pma__designer_settings {
    private $username;
    private $settings_data;

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getSettings_data() {
        return $this->settings_data;
    }

    public function setSettings_data($settings_data) {
        $this->settings_data = $settings_data;
    }

}