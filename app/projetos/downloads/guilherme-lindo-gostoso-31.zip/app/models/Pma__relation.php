<?php

namespace app\models;

class Pma__relation {
    private $master_db;
    private $master_table;
    private $master_field;
    private $foreign_db;
    private $foreign_table;
    private $foreign_field;

    public function getMaster_db() {
        return $this->master_db;
    }

    public function setMaster_db($master_db) {
        $this->master_db = $master_db;
    }

    public function getMaster_table() {
        return $this->master_table;
    }

    public function setMaster_table($master_table) {
        $this->master_table = $master_table;
    }

    public function getMaster_field() {
        return $this->master_field;
    }

    public function setMaster_field($master_field) {
        $this->master_field = $master_field;
    }

    public function getForeign_db() {
        return $this->foreign_db;
    }

    public function setForeign_db($foreign_db) {
        $this->foreign_db = $foreign_db;
    }

    public function getForeign_table() {
        return $this->foreign_table;
    }

    public function setForeign_table($foreign_table) {
        $this->foreign_table = $foreign_table;
    }

    public function getForeign_field() {
        return $this->foreign_field;
    }

    public function setForeign_field($foreign_field) {
        $this->foreign_field = $foreign_field;
    }

}