<?php

namespace app\models;

class Pma__savedsearches {
    private $id;
    private $username;
    private $db_name;
    private $search_name;
    private $search_data;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getSearch_name() {
        return $this->search_name;
    }

    public function setSearch_name($search_name) {
        $this->search_name = $search_name;
    }

    public function getSearch_data() {
        return $this->search_data;
    }

    public function setSearch_data($search_data) {
        $this->search_data = $search_data;
    }

}