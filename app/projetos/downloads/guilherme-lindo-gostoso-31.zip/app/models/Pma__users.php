<?php

namespace app\models;

class Pma__users {
    private $username;
    private $usergroup;

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getUsergroup() {
        return $this->usergroup;
    }

    public function setUsergroup($usergroup) {
        $this->usergroup = $usergroup;
    }

}