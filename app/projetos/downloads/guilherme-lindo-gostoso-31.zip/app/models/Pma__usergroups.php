<?php

namespace app\models;

class Pma__usergroups {
    private $usergroup;
    private $tab;
    private $allowed;

    public function getUsergroup() {
        return $this->usergroup;
    }

    public function setUsergroup($usergroup) {
        $this->usergroup = $usergroup;
    }

    public function getTab() {
        return $this->tab;
    }

    public function setTab($tab) {
        $this->tab = $tab;
    }

    public function getAllowed() {
        return $this->allowed;
    }

    public function setAllowed($allowed) {
        $this->allowed = $allowed;
    }

}