<?php

namespace app\models;

class Pma__navigationhiding {
    private $username;
    private $item_name;
    private $item_type;
    private $db_name;
    private $table_name;

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getItem_name() {
        return $this->item_name;
    }

    public function setItem_name($item_name) {
        $this->item_name = $item_name;
    }

    public function getItem_type() {
        return $this->item_type;
    }

    public function setItem_type($item_type) {
        $this->item_type = $item_type;
    }

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getTable_name() {
        return $this->table_name;
    }

    public function setTable_name($table_name) {
        $this->table_name = $table_name;
    }

}