<?php

namespace app\models;

class Pma__pdf_pages {
    private $db_name;
    private $page_nr;
    private $page_descr;

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getPage_nr() {
        return $this->page_nr;
    }

    public function setPage_nr($page_nr) {
        $this->page_nr = $page_nr;
    }

    public function getPage_descr() {
        return $this->page_descr;
    }

    public function setPage_descr($page_descr) {
        $this->page_descr = $page_descr;
    }

}