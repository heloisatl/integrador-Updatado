<?php

namespace app\models;

class Pma__column_info {
    private $id;
    private $db_name;
    private $table_name;
    private $column_name;
    private $comment;
    private $mimetype;
    private $transformation;
    private $transformation_options;
    private $input_transformation;
    private $input_transformation_options;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getTable_name() {
        return $this->table_name;
    }

    public function setTable_name($table_name) {
        $this->table_name = $table_name;
    }

    public function getColumn_name() {
        return $this->column_name;
    }

    public function setColumn_name($column_name) {
        $this->column_name = $column_name;
    }

    public function getComment() {
        return $this->comment;
    }

    public function setComment($comment) {
        $this->comment = $comment;
    }

    public function getMimetype() {
        return $this->mimetype;
    }

    public function setMimetype($mimetype) {
        $this->mimetype = $mimetype;
    }

    public function getTransformation() {
        return $this->transformation;
    }

    public function setTransformation($transformation) {
        $this->transformation = $transformation;
    }

    public function getTransformation_options() {
        return $this->transformation_options;
    }

    public function setTransformation_options($transformation_options) {
        $this->transformation_options = $transformation_options;
    }

    public function getInput_transformation() {
        return $this->input_transformation;
    }

    public function setInput_transformation($input_transformation) {
        $this->input_transformation = $input_transformation;
    }

    public function getInput_transformation_options() {
        return $this->input_transformation_options;
    }

    public function setInput_transformation_options($input_transformation_options) {
        $this->input_transformation_options = $input_transformation_options;
    }

}