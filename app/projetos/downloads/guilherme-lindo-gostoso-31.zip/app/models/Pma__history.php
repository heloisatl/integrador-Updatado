<?php

namespace app\models;

class Pma__history {
    private $id;
    private $username;
    private $db;
    private $table;
    private $timevalue;
    private $sqlquery;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getDb() {
        return $this->db;
    }

    public function setDb($db) {
        $this->db = $db;
    }

    public function getTable() {
        return $this->table;
    }

    public function setTable($table) {
        $this->table = $table;
    }

    public function getTimevalue() {
        return $this->timevalue;
    }

    public function setTimevalue($timevalue) {
        $this->timevalue = $timevalue;
    }

    public function getSqlquery() {
        return $this->sqlquery;
    }

    public function setSqlquery($sqlquery) {
        $this->sqlquery = $sqlquery;
    }

}