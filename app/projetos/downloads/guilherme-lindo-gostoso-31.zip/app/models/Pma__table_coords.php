<?php

namespace app\models;

class Pma__table_coords {
    private $db_name;
    private $table_name;
    private $pdf_page_number;
    private $x;
    private $y;

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getTable_name() {
        return $this->table_name;
    }

    public function setTable_name($table_name) {
        $this->table_name = $table_name;
    }

    public function getPdf_page_number() {
        return $this->pdf_page_number;
    }

    public function setPdf_page_number($pdf_page_number) {
        $this->pdf_page_number = $pdf_page_number;
    }

    public function getX() {
        return $this->x;
    }

    public function setX($x) {
        $this->x = $x;
    }

    public function getY() {
        return $this->y;
    }

    public function setY($y) {
        $this->y = $y;
    }

}