<?php

namespace app\models;

class Pma__bookmark {
    private $id;
    private $dbase;
    private $user;
    private $label;
    private $query;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getDbase() {
        return $this->dbase;
    }

    public function setDbase($dbase) {
        $this->dbase = $dbase;
    }

    public function getUser() {
        return $this->user;
    }

    public function setUser($user) {
        $this->user = $user;
    }

    public function getLabel() {
        return $this->label;
    }

    public function setLabel($label) {
        $this->label = $label;
    }

    public function getQuery() {
        return $this->query;
    }

    public function setQuery($query) {
        $this->query = $query;
    }

}