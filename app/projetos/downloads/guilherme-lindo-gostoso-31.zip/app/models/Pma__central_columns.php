<?php

namespace app\models;

class Pma__central_columns {
    private $db_name;
    private $col_name;
    private $col_type;
    private $col_length;
    private $col_collation;
    private $col_isNull;
    private $col_extra;
    private $col_default;

    public function getDb_name() {
        return $this->db_name;
    }

    public function setDb_name($db_name) {
        $this->db_name = $db_name;
    }

    public function getCol_name() {
        return $this->col_name;
    }

    public function setCol_name($col_name) {
        $this->col_name = $col_name;
    }

    public function getCol_type() {
        return $this->col_type;
    }

    public function setCol_type($col_type) {
        $this->col_type = $col_type;
    }

    public function getCol_length() {
        return $this->col_length;
    }

    public function setCol_length($col_length) {
        $this->col_length = $col_length;
    }

    public function getCol_collation() {
        return $this->col_collation;
    }

    public function setCol_collation($col_collation) {
        $this->col_collation = $col_collation;
    }

    public function getCol_isNull() {
        return $this->col_isNull;
    }

    public function setCol_isNull($col_isNull) {
        $this->col_isNull = $col_isNull;
    }

    public function getCol_extra() {
        return $this->col_extra;
    }

    public function setCol_extra($col_extra) {
        $this->col_extra = $col_extra;
    }

    public function getCol_default() {
        return $this->col_default;
    }

    public function setCol_default($col_default) {
        $this->col_default = $col_default;
    }

}