<?php

namespace app\services;

use app\models\Pma__navigationhiding;
use app\repositories\Pma__navigationhidingRepository;

class Pma__navigationhidingService {
    private Pma__navigationhidingRepository $repository;

    public function __construct() {
        $this->repository = new Pma__navigationhidingRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__navigationhiding $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__navigationhiding $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
