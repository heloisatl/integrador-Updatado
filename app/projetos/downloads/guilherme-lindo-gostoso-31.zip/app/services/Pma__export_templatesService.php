<?php

namespace app\services;

use app\models\Pma__export_templates;
use app\repositories\Pma__export_templatesRepository;

class Pma__export_templatesService {
    private Pma__export_templatesRepository $repository;

    public function __construct() {
        $this->repository = new Pma__export_templatesRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__export_templates $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__export_templates $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
