<?php

namespace app\services;

use app\models\Pma__savedsearches;
use app\repositories\Pma__savedsearchesRepository;

class Pma__savedsearchesService {
    private Pma__savedsearchesRepository $repository;

    public function __construct() {
        $this->repository = new Pma__savedsearchesRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__savedsearches $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__savedsearches $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
