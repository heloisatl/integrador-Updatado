<?php

namespace app\services;

use app\models\Pma__designer_settings;
use app\repositories\Pma__designer_settingsRepository;

class Pma__designer_settingsService {
    private Pma__designer_settingsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__designer_settingsRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__designer_settings $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__designer_settings $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
