<?php

namespace app\services;

use app\models\Pma__usergroups;
use app\repositories\Pma__usergroupsRepository;

class Pma__usergroupsService {
    private Pma__usergroupsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__usergroupsRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__usergroups $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__usergroups $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
