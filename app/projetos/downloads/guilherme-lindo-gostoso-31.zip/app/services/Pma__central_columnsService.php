<?php

namespace app\services;

use app\models\Pma__central_columns;
use app\repositories\Pma__central_columnsRepository;

class Pma__central_columnsService {
    private Pma__central_columnsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__central_columnsRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__central_columns $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__central_columns $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
