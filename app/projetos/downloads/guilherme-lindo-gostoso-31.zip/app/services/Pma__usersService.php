<?php

namespace app\services;

use app\models\Pma__users;
use app\repositories\Pma__usersRepository;

class Pma__usersService {
    private Pma__usersRepository $repository;

    public function __construct() {
        $this->repository = new Pma__usersRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__users $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__users $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
