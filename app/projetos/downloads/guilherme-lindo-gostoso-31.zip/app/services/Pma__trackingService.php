<?php

namespace app\services;

use app\models\Pma__tracking;
use app\repositories\Pma__trackingRepository;

class Pma__trackingService {
    private Pma__trackingRepository $repository;

    public function __construct() {
        $this->repository = new Pma__trackingRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__tracking $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__tracking $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
