<?php

namespace app\services;

use app\models\Pma__userconfig;
use app\repositories\Pma__userconfigRepository;

class Pma__userconfigService {
    private Pma__userconfigRepository $repository;

    public function __construct() {
        $this->repository = new Pma__userconfigRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__userconfig $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__userconfig $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
