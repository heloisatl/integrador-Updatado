<?php

namespace app\services;

use app\models\Pma__history;
use app\repositories\Pma__historyRepository;

class Pma__historyService {
    private Pma__historyRepository $repository;

    public function __construct() {
        $this->repository = new Pma__historyRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__history $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__history $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
