<?php

namespace app\services;

use app\models\Pma__recent;
use app\repositories\Pma__recentRepository;

class Pma__recentService {
    private Pma__recentRepository $repository;

    public function __construct() {
        $this->repository = new Pma__recentRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__recent $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__recent $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
