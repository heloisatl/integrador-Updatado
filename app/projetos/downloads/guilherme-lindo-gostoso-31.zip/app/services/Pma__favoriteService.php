<?php

namespace app\services;

use app\models\Pma__favorite;
use app\repositories\Pma__favoriteRepository;

class Pma__favoriteService {
    private Pma__favoriteRepository $repository;

    public function __construct() {
        $this->repository = new Pma__favoriteRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__favorite $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__favorite $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
