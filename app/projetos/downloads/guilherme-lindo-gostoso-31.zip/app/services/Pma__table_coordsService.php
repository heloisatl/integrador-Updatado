<?php

namespace app\services;

use app\models\Pma__table_coords;
use app\repositories\Pma__table_coordsRepository;

class Pma__table_coordsService {
    private Pma__table_coordsRepository $repository;

    public function __construct() {
        $this->repository = new Pma__table_coordsRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__table_coords $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__table_coords $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
