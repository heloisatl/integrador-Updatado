<?php

namespace app\services;

use app\models\Pma__pdf_pages;
use app\repositories\Pma__pdf_pagesRepository;

class Pma__pdf_pagesService {
    private Pma__pdf_pagesRepository $repository;

    public function __construct() {
        $this->repository = new Pma__pdf_pagesRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__pdf_pages $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__pdf_pages $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
