<?php

namespace app\services;

use app\models\Pma__table_info;
use app\repositories\Pma__table_infoRepository;

class Pma__table_infoService {
    private Pma__table_infoRepository $repository;

    public function __construct() {
        $this->repository = new Pma__table_infoRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__table_info $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__table_info $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
