<?php

namespace app\services;

use app\models\Pma__column_info;
use app\repositories\Pma__column_infoRepository;

class Pma__column_infoService {
    private Pma__column_infoRepository $repository;

    public function __construct() {
        $this->repository = new Pma__column_infoRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__column_info $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__column_info $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
