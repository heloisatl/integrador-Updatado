<?php

namespace app\services;

use app\models\Pma__relation;
use app\repositories\Pma__relationRepository;

class Pma__relationService {
    private Pma__relationRepository $repository;

    public function __construct() {
        $this->repository = new Pma__relationRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__relation $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__relation $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
