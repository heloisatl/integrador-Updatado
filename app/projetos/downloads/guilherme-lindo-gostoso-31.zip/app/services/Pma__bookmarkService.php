<?php

namespace app\services;

use app\models\Pma__bookmark;
use app\repositories\Pma__bookmarkRepository;

class Pma__bookmarkService {
    private Pma__bookmarkRepository $repository;

    public function __construct() {
        $this->repository = new Pma__bookmarkRepository();
    }

    public function listarTodos(): array {
        return $this->repository->listarTodos();
    }

    public function buscarPorId(int $id): ?array {
        return $this->repository->buscarPorId($id);
    }

    public function inserir(Pma__bookmark $obj): bool {
        return $this->repository->inserir($obj);
    }

    public function alterar(Pma__bookmark $obj, int $id): bool {
        return $this->repository->alterar($obj, $id);
    }

    public function excluir(int $id): bool {
        return $this->repository->excluir($id);
    }
}
