<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Pma__savedsearches;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Pma__savedsearches
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'pma__savedsearches':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class Pma__savedsearchesRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Pma__savedsearches $obj): bool {
        $sql = "INSERT INTO pma__savedsearches (username, db_name, search_name, search_data) VALUES (?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $username = $obj->getUsername();
        $db_name = $obj->getDb_name();
        $search_name = $obj->getSearch_name();
        $search_data = $obj->getSearch_data();

        return $stmt->execute([$username, $db_name, $search_name, $search_data]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__savedsearches";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__savedsearches WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Pma__savedsearches $obj, int $id): bool {
        $username = $obj->getUsername();
        $db_name = $obj->getDb_name();
        $search_name = $obj->getSearch_name();
        $search_data = $obj->getSearch_data();

        $sql = "UPDATE pma__savedsearches SET username = ?, db_name = ?, search_name = ?, search_data = ? WHERE id = ?";
        $params = [$username, $db_name, $search_name, $search_data, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__savedsearches WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}