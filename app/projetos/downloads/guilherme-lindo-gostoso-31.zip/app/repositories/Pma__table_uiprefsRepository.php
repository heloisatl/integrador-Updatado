<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Pma__table_uiprefs;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Pma__table_uiprefs
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'pma__table_uiprefs':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class Pma__table_uiprefsRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Pma__table_uiprefs $obj): bool {
        $sql = "INSERT INTO pma__table_uiprefs (prefs, last_update) VALUES (?, ?)";
        $stmt = $this->con->prepare($sql);
        $prefs = $obj->getPrefs();
        $last_update = $obj->getLast_update();

        return $stmt->execute([$prefs, $last_update]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__table_uiprefs";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('table_name').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__table_uiprefs WHERE table_name = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Pma__table_uiprefs $obj, int $id): bool {
        $prefs = $obj->getPrefs();
        $last_update = $obj->getLast_update();

        $sql = "UPDATE pma__table_uiprefs SET prefs = ?, last_update = ? WHERE table_name = ?";
        $params = [$prefs, $last_update, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__table_uiprefs WHERE table_name = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}