<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Pma__central_columns;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Pma__central_columns
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'pma__central_columns':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class Pma__central_columnsRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Pma__central_columns $obj): bool {
        $sql = "INSERT INTO pma__central_columns (col_type, col_length, col_collation, col_isNull, col_extra, col_default) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $col_type = $obj->getCol_type();
        $col_length = $obj->getCol_length();
        $col_collation = $obj->getCol_collation();
        $col_isNull = $obj->getCol_isNull();
        $col_extra = $obj->getCol_extra();
        $col_default = $obj->getCol_default();

        return $stmt->execute([$col_type, $col_length, $col_collation, $col_isNull, $col_extra, $col_default]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__central_columns";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('col_name').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__central_columns WHERE col_name = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Pma__central_columns $obj, int $id): bool {
        $col_type = $obj->getCol_type();
        $col_length = $obj->getCol_length();
        $col_collation = $obj->getCol_collation();
        $col_isNull = $obj->getCol_isNull();
        $col_extra = $obj->getCol_extra();
        $col_default = $obj->getCol_default();

        $sql = "UPDATE pma__central_columns SET col_type = ?, col_length = ?, col_collation = ?, col_isNull = ?, col_extra = ?, col_default = ? WHERE col_name = ?";
        $params = [$col_type, $col_length, $col_collation, $col_isNull, $col_extra, $col_default, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__central_columns WHERE col_name = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}