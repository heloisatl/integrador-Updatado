<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Pma__column_info;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Pma__column_info
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'pma__column_info':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class Pma__column_infoRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Pma__column_info $obj): bool {
        $sql = "INSERT INTO pma__column_info (db_name, table_name, column_name, comment, mimetype, transformation, transformation_options, input_transformation, input_transformation_options) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $db_name = $obj->getDb_name();
        $table_name = $obj->getTable_name();
        $column_name = $obj->getColumn_name();
        $comment = $obj->getComment();
        $mimetype = $obj->getMimetype();
        $transformation = $obj->getTransformation();
        $transformation_options = $obj->getTransformation_options();
        $input_transformation = $obj->getInput_transformation();
        $input_transformation_options = $obj->getInput_transformation_options();

        return $stmt->execute([$db_name, $table_name, $column_name, $comment, $mimetype, $transformation, $transformation_options, $input_transformation, $input_transformation_options]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__column_info";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__column_info WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Pma__column_info $obj, int $id): bool {
        $db_name = $obj->getDb_name();
        $table_name = $obj->getTable_name();
        $column_name = $obj->getColumn_name();
        $comment = $obj->getComment();
        $mimetype = $obj->getMimetype();
        $transformation = $obj->getTransformation();
        $transformation_options = $obj->getTransformation_options();
        $input_transformation = $obj->getInput_transformation();
        $input_transformation_options = $obj->getInput_transformation_options();

        $sql = "UPDATE pma__column_info SET db_name = ?, table_name = ?, column_name = ?, comment = ?, mimetype = ?, transformation = ?, transformation_options = ?, input_transformation = ?, input_transformation_options = ? WHERE id = ?";
        $params = [$db_name, $table_name, $column_name, $comment, $mimetype, $transformation, $transformation_options, $input_transformation, $input_transformation_options, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__column_info WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}