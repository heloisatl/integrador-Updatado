<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Pma__pdf_pages;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Pma__pdf_pages
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'pma__pdf_pages':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class Pma__pdf_pagesRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Pma__pdf_pages $obj): bool {
        $sql = "INSERT INTO pma__pdf_pages (db_name, page_descr) VALUES (?, ?)";
        $stmt = $this->con->prepare($sql);
        $db_name = $obj->getDb_name();
        $page_descr = $obj->getPage_descr();

        return $stmt->execute([$db_name, $page_descr]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__pdf_pages";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('page_nr').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__pdf_pages WHERE page_nr = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Pma__pdf_pages $obj, int $id): bool {
        $db_name = $obj->getDb_name();
        $page_descr = $obj->getPage_descr();

        $sql = "UPDATE pma__pdf_pages SET db_name = ?, page_descr = ? WHERE page_nr = ?";
        $params = [$db_name, $page_descr, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__pdf_pages WHERE page_nr = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}