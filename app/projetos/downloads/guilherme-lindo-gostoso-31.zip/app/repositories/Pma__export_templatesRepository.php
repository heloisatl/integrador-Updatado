<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Pma__export_templates;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Pma__export_templates
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'pma__export_templates':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class Pma__export_templatesRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Pma__export_templates $obj): bool {
        $sql = "INSERT INTO pma__export_templates (username, export_type, template_name, template_data) VALUES (?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $username = $obj->getUsername();
        $export_type = $obj->getExport_type();
        $template_name = $obj->getTemplate_name();
        $template_data = $obj->getTemplate_data();

        return $stmt->execute([$username, $export_type, $template_name, $template_data]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__export_templates";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__export_templates WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Pma__export_templates $obj, int $id): bool {
        $username = $obj->getUsername();
        $export_type = $obj->getExport_type();
        $template_name = $obj->getTemplate_name();
        $template_data = $obj->getTemplate_data();

        $sql = "UPDATE pma__export_templates SET username = ?, export_type = ?, template_name = ?, template_data = ? WHERE id = ?";
        $params = [$username, $export_type, $template_name, $template_data, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__export_templates WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}