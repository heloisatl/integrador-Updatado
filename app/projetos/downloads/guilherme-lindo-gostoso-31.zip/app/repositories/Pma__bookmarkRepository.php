<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Pma__bookmark;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Pma__bookmark
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'pma__bookmark':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class Pma__bookmarkRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Pma__bookmark $obj): bool {
        $sql = "INSERT INTO pma__bookmark (dbase, user, label, query) VALUES (?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $dbase = $obj->getDbase();
        $user = $obj->getUser();
        $label = $obj->getLabel();
        $query = $obj->getQuery();

        return $stmt->execute([$dbase, $user, $label, $query]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__bookmark";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('id').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__bookmark WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Pma__bookmark $obj, int $id): bool {
        $dbase = $obj->getDbase();
        $user = $obj->getUser();
        $label = $obj->getLabel();
        $query = $obj->getQuery();

        $sql = "UPDATE pma__bookmark SET dbase = ?, user = ?, label = ?, query = ? WHERE id = ?";
        $params = [$dbase, $user, $label, $query, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__bookmark WHERE id = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}