<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Pma__tracking;
use PDO;

/**
 * Camada de Acesso a Dados (DAO / Repository) - Entidade Pma__tracking
 *
 * Esta classe gerencia a persistência no MySQL para a tabela 'pma__tracking':
 * - Comunicação segura via extensão PDO (PHP Data Objects);
 * - Uso obrigatório de Prepared Statements contra ataques de SQL Injection;
 * - Implementação dos métodos fundamentais do CRUD (Create, Read, Update, Delete).
 */
class Pma__trackingRepository {
    private PDO $con;

    /**
     * Obtém a instância única de conexão PDO via ConnectionFactory (Padrão Singleton).
     */
    public function __construct() {
        $this->con = ConnectionFactory::getConnection();
    }

    /**
     * CREATE: Insere um novo registro com segurança utilizando Prepared Statement.
     * O método prepare() pré-compila a instrução e execute() envia os dados separadamente,
     * prevenindo que valores do usuário sejam interpretados como código SQL malicioso.
     */
    public function inserir(Pma__tracking $obj): bool {
        $sql = "INSERT INTO pma__tracking (date_created, date_updated, schema_snapshot, schema_sql, data_sql, tracking, tracking_active) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $date_created = $obj->getDate_created();
        $date_updated = $obj->getDate_updated();
        $schema_snapshot = $obj->getSchema_snapshot();
        $schema_sql = $obj->getSchema_sql();
        $data_sql = $obj->getData_sql();
        $tracking = $obj->getTracking();
        $tracking_active = $obj->getTracking_active();

        return $stmt->execute([$date_created, $date_updated, $schema_snapshot, $schema_sql, $data_sql, $tracking, $tracking_active]);
    }

    /**
     * READ: Retorna todos os registros cadastrados na tabela como arrays associativos (PDO::FETCH_ASSOC).
     */
    public function listarTodos(): array {
        $sql = "SELECT * FROM pma__tracking";
        $query = $this->con->query($sql);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * READ: Localiza um registro específico com base na Chave Primária ('version').
     * O identificador é parametrizado com segurança para evitar injeção de SQL.
     */
    public function buscarPorId(int $id): ?array {
        $sql = "SELECT * FROM pma__tracking WHERE version = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }

    /**
     * UPDATE: Atualiza os dados de um registro existente com base no ID.
     * Monta a cláusula SET parametrizada e vincula o identificador ao final dos parâmetros.
     */
    public function alterar(Pma__tracking $obj, int $id): bool {
        $date_created = $obj->getDate_created();
        $date_updated = $obj->getDate_updated();
        $schema_snapshot = $obj->getSchema_snapshot();
        $schema_sql = $obj->getSchema_sql();
        $data_sql = $obj->getData_sql();
        $tracking = $obj->getTracking();
        $tracking_active = $obj->getTracking_active();

        $sql = "UPDATE pma__tracking SET date_created = ?, date_updated = ?, schema_snapshot = ?, schema_sql = ?, data_sql = ?, tracking = ?, tracking_active = ? WHERE version = ?";
        $params = [$date_created, $date_updated, $schema_snapshot, $schema_sql, $data_sql, $tracking, $tracking_active, $id];
        $stmt = $this->con->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * DELETE: Remove definitivamente um registro da tabela pelo seu identificador único.
     */
    public function excluir(int $id): bool {
        $sql = "DELETE FROM pma__tracking WHERE version = ?";
        $stmt = $this->con->prepare($sql);
        return $stmt->execute([$id]);
    }
}