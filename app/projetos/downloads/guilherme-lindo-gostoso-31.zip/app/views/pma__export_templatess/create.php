

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__export_templates</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__export_templatess" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__export_templatess/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='username' id='username' value='<?= $obj?$obj['username']:''?>'><br>
<input type='text' name='export_type' id='export_type' value='<?= $obj?$obj['export_type']:''?>'><br>
<input type='text' name='template_name' id='template_name' value='<?= $obj?$obj['template_name']:''?>'><br>
<input type='text' name='template_data' id='template_data' value='<?= $obj?$obj['template_data']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>