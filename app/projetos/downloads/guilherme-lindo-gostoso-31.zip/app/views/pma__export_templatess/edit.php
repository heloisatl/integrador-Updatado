

<div class="page-header">
    <h1 class="page-title">Editar Pma__export_templates</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__export_templatess" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__export_templatess/atualizar" method="POST">
<?php $obj = $pma__export_templates; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__export_templates['id'] ?? '') ?>">
<input type='text' name='username' id='username' value='<?= $obj?$obj['username']:''?>'><br>
<input type='text' name='export_type' id='export_type' value='<?= $obj?$obj['export_type']:''?>'><br>
<input type='text' name='template_name' id='template_name' value='<?= $obj?$obj['template_name']:''?>'><br>
<input type='text' name='template_data' id='template_data' value='<?= $obj?$obj['template_data']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>