

<div class="page-header">
    <h1 class="page-title">Editar Pma__central_columns</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__central_columnss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__central_columnss/atualizar" method="POST">
<?php $obj = $pma__central_columns; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__central_columns['db_name'] ?? '') ?>">
<input type='text' name='col_type' id='col_type' value='<?= $obj?$obj['col_type']:''?>'><br>
<input type='text' name='col_length' id='col_length' value='<?= $obj?$obj['col_length']:''?>'><br>
<input type='text' name='col_collation' id='col_collation' value='<?= $obj?$obj['col_collation']:''?>'><br>
<p><b>Erro:o tipo de atributo tinyint(1) não foi reconhecido.</b></p><input type='text' name='col_extra' id='col_extra' value='<?= $obj?$obj['col_extra']:''?>'><br>
<input type='text' name='col_default' id='col_default' value='<?= $obj?$obj['col_default']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>