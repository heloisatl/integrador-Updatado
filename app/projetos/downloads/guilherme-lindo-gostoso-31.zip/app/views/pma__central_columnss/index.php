

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__central_columns</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__central_columnss/cadastrar" class="btn btn-primary">
            Novo Pma__central_columns
        </a>
    </div>
</div>

<?php if (empty($pma__central_columnss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__central_columnss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__central_columns
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Db_name</th>
                    <th>Col_name</th>
                    <th>Col_type</th>
                    <th>Col_length</th>
                    <th>Col_collation</th>
                    <th>Col_isNull</th>
                    <th>Col_extra</th>
                    <th>Col_default</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__central_columnss as $pma__central_columns): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__central_columns['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_length'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_collation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_isNull'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_extra'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__central_columns['col_default'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__central_columnss/editar?id=<?= $pma__central_columns['db_name'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__central_columnss/excluir?id=<?= $pma__central_columns['db_name'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>