

<div class="page-header">
    <h1 class="page-title">Editar Pma__savedsearches</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__savedsearchess" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__savedsearchess/atualizar" method="POST">
<?php $obj = $pma__savedsearches; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__savedsearches['id'] ?? '') ?>">
<input type='text' name='username' id='username' value='<?= $obj?$obj['username']:''?>'><br>
<input type='text' name='db_name' id='db_name' value='<?= $obj?$obj['db_name']:''?>'><br>
<input type='text' name='search_name' id='search_name' value='<?= $obj?$obj['search_name']:''?>'><br>
<input type='text' name='search_data' id='search_data' value='<?= $obj?$obj['search_data']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>