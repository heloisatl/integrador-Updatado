

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__savedsearches</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__savedsearchess/cadastrar" class="btn btn-primary">
            Novo Pma__savedsearches
        </a>
    </div>
</div>

<?php if (empty($pma__savedsearchess)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__savedsearchess/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__savedsearches
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Username</th>
                    <th>Db_name</th>
                    <th>Search_name</th>
                    <th>Search_data</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__savedsearchess as $pma__savedsearches): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__savedsearches['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__savedsearches['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__savedsearches['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__savedsearches['search_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__savedsearches['search_data'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__savedsearchess/editar?id=<?= $pma__savedsearches['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__savedsearchess/excluir?id=<?= $pma__savedsearches['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>