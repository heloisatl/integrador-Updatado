

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__favorite</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__favorites" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__favorites/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='tables' id='tables' value='<?= $obj?$obj['tables']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>