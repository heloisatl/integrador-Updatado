

<div class="page-header">
    <h1 class="page-title">Editar Pma__favorite</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__favorites" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__favorites/atualizar" method="POST">
<?php $obj = $pma__favorite; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__favorite['username'] ?? '') ?>">
<input type='text' name='tables' id='tables' value='<?= $obj?$obj['tables']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>