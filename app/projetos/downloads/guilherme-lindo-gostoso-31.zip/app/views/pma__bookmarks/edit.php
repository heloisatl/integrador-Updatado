

<div class="page-header">
    <h1 class="page-title">Editar Pma__bookmark</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__bookmarks" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__bookmarks/atualizar" method="POST">
<?php $obj = $pma__bookmark; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__bookmark['id'] ?? '') ?>">
<input type='text' name='dbase' id='dbase' value='<?= $obj?$obj['dbase']:''?>'><br>
<input type='text' name='user' id='user' value='<?= $obj?$obj['user']:''?>'><br>
<input type='text' name='label' id='label' value='<?= $obj?$obj['label']:''?>'><br>
<input type='text' name='query' id='query' value='<?= $obj?$obj['query']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>