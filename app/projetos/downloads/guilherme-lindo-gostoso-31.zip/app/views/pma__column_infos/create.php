

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__column_info</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__column_infos" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__column_infos/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='db_name' id='db_name' value='<?= $obj?$obj['db_name']:''?>'><br>
<input type='text' name='table_name' id='table_name' value='<?= $obj?$obj['table_name']:''?>'><br>
<input type='text' name='column_name' id='column_name' value='<?= $obj?$obj['column_name']:''?>'><br>
<input type='text' name='comment' id='comment' value='<?= $obj?$obj['comment']:''?>'><br>
<input type='text' name='mimetype' id='mimetype' value='<?= $obj?$obj['mimetype']:''?>'><br>
<input type='text' name='transformation' id='transformation' value='<?= $obj?$obj['transformation']:''?>'><br>
<input type='text' name='transformation_options' id='transformation_options' value='<?= $obj?$obj['transformation_options']:''?>'><br>
<input type='text' name='input_transformation' id='input_transformation' value='<?= $obj?$obj['input_transformation']:''?>'><br>
<input type='text' name='input_transformation_options' id='input_transformation_options' value='<?= $obj?$obj['input_transformation_options']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>