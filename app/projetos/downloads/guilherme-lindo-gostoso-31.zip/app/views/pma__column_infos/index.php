

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__column_info</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__column_infos/cadastrar" class="btn btn-primary">
            Novo Pma__column_info
        </a>
    </div>
</div>

<?php if (empty($pma__column_infos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__column_infos/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__column_info
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Db_name</th>
                    <th>Table_name</th>
                    <th>Column_name</th>
                    <th>Comment</th>
                    <th>Mimetype</th>
                    <th>Transformation</th>
                    <th>Transformation_options</th>
                    <th>Input_transformation</th>
                    <th>Input_transformation_options</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__column_infos as $pma__column_info): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__column_info['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__column_info['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__column_info['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__column_info['column_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__column_info['comment'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__column_info['mimetype'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__column_info['transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__column_info['transformation_options'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__column_info['input_transformation'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__column_info['input_transformation_options'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__column_infos/editar?id=<?= $pma__column_info['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__column_infos/excluir?id=<?= $pma__column_info['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>