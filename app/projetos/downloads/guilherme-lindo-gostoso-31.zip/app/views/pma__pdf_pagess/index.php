

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__pdf_pages</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__pdf_pagess/cadastrar" class="btn btn-primary">
            Novo Pma__pdf_pages
        </a>
    </div>
</div>

<?php if (empty($pma__pdf_pagess)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__pdf_pagess/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__pdf_pages
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Db_name</th>
                    <th>Page_nr</th>
                    <th>Page_descr</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__pdf_pagess as $pma__pdf_pages): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__pdf_pages['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['page_nr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__pdf_pages['page_descr'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__pdf_pagess/editar?id=<?= $pma__pdf_pages['page_nr'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__pdf_pagess/excluir?id=<?= $pma__pdf_pages['page_nr'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>