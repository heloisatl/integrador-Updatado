

<div class="page-header">
    <h1 class="page-title">Editar Pma__pdf_pages</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__pdf_pagess" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__pdf_pagess/atualizar" method="POST">
<?php $obj = $pma__pdf_pages; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__pdf_pages['page_nr'] ?? '') ?>">
<input type='text' name='db_name' id='db_name' value='<?= $obj?$obj['db_name']:''?>'><br>
<input type='text' name='page_descr' id='page_descr' value='<?= $obj?$obj['page_descr']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>