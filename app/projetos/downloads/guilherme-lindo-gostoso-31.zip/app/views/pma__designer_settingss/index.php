

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__designer_settings</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__designer_settingss/cadastrar" class="btn btn-primary">
            Novo Pma__designer_settings
        </a>
    </div>
</div>

<?php if (empty($pma__designer_settingss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__designer_settingss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__designer_settings
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Settings_data</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__designer_settingss as $pma__designer_settings): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__designer_settings['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__designer_settings['settings_data'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__designer_settingss/editar?id=<?= $pma__designer_settings['username'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__designer_settingss/excluir?id=<?= $pma__designer_settings['username'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>