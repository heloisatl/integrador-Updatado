

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__designer_settings</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__designer_settingss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__designer_settingss/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='settings_data' id='settings_data' value='<?= $obj?$obj['settings_data']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>