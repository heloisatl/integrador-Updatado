

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__relation</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__relations" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__relations/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='foreign_db' id='foreign_db' value='<?= $obj?$obj['foreign_db']:''?>'><br>
<input type='text' name='foreign_table' id='foreign_table' value='<?= $obj?$obj['foreign_table']:''?>'><br>
<input type='text' name='foreign_field' id='foreign_field' value='<?= $obj?$obj['foreign_field']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>