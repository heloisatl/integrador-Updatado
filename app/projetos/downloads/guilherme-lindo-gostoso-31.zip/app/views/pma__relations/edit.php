

<div class="page-header">
    <h1 class="page-title">Editar Pma__relation</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__relations" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__relations/atualizar" method="POST">
<?php $obj = $pma__relation; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__relation['master_db'] ?? '') ?>">
<input type='text' name='foreign_db' id='foreign_db' value='<?= $obj?$obj['foreign_db']:''?>'><br>
<input type='text' name='foreign_table' id='foreign_table' value='<?= $obj?$obj['foreign_table']:''?>'><br>
<input type='text' name='foreign_field' id='foreign_field' value='<?= $obj?$obj['foreign_field']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>