

<div class="page-header">
    <h1 class="page-title">Editar Pma__users</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__userss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__userss/atualizar" method="POST">
<?php $obj = $pma__users; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__users['username'] ?? '') ?>">

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>