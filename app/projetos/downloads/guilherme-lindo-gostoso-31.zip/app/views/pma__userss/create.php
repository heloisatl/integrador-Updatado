

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__users</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__userss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__userss/salvar" method="POST">
<?php $obj = null; ?>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>