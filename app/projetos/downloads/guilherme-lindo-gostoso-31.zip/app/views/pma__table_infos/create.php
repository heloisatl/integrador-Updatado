

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__table_info</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_infos" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__table_infos/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='display_field' id='display_field' value='<?= $obj?$obj['display_field']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>