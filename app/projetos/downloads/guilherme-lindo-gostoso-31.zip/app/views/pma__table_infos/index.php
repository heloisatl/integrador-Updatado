

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__table_info</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_infos/cadastrar" class="btn btn-primary">
            Novo Pma__table_info
        </a>
    </div>
</div>

<?php if (empty($pma__table_infos)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__table_infos/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__table_info
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Db_name</th>
                    <th>Table_name</th>
                    <th>Display_field</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__table_infos as $pma__table_info): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__table_info['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_info['display_field'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__table_infos/editar?id=<?= $pma__table_info['db_name'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__table_infos/excluir?id=<?= $pma__table_info['db_name'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>