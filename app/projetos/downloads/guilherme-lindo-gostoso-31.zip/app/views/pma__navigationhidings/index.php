

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__navigationhiding</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__navigationhidings/cadastrar" class="btn btn-primary">
            Novo Pma__navigationhiding
        </a>
    </div>
</div>

<?php if (empty($pma__navigationhidings)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__navigationhidings/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__navigationhiding
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Item_name</th>
                    <th>Item_type</th>
                    <th>Db_name</th>
                    <th>Table_name</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__navigationhidings as $pma__navigationhiding): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__navigationhiding['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__navigationhiding['item_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__navigationhiding['item_type'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__navigationhiding['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__navigationhiding['table_name'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__navigationhidings/editar?id=<?= $pma__navigationhiding['username'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__navigationhidings/excluir?id=<?= $pma__navigationhiding['username'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>