

<div class="page-header">
    <h1 class="page-title">Editar Pma__navigationhiding</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__navigationhidings" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__navigationhidings/atualizar" method="POST">
<?php $obj = $pma__navigationhiding; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__navigationhiding['username'] ?? '') ?>">

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>