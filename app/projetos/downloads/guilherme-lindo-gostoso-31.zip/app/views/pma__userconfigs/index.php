

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__userconfig</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__userconfigs/cadastrar" class="btn btn-primary">
            Novo Pma__userconfig
        </a>
    </div>
</div>

<?php if (empty($pma__userconfigs)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__userconfigs/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__userconfig
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Timevalue</th>
                    <th>Config_data</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__userconfigs as $pma__userconfig): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__userconfig['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__userconfig['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__userconfig['config_data'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__userconfigs/editar?id=<?= $pma__userconfig['username'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__userconfigs/excluir?id=<?= $pma__userconfig['username'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>