

<div class="page-header">
    <h1 class="page-title">Editar Pma__userconfig</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__userconfigs" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__userconfigs/atualizar" method="POST">
<?php $obj = $pma__userconfig; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__userconfig['username'] ?? '') ?>">
<p><b>Erro:o tipo de atributo timestamp não foi reconhecido.</b></p><input type='text' name='config_data' id='config_data' value='<?= $obj?$obj['config_data']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>