

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__usergroups</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__usergroupss/cadastrar" class="btn btn-primary">
            Novo Pma__usergroups
        </a>
    </div>
</div>

<?php if (empty($pma__usergroupss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__usergroupss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__usergroups
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Usergroup</th>
                    <th>Tab</th>
                    <th>Allowed</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__usergroupss as $pma__usergroups): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__usergroups['usergroup'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['tab'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__usergroups['allowed'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__usergroupss/editar?id=<?= $pma__usergroups['usergroup'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__usergroupss/excluir?id=<?= $pma__usergroups['usergroup'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>