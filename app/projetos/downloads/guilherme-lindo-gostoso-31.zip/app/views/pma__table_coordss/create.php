

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__table_coords</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_coordss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__table_coordss/salvar" method="POST">
<?php $obj = null; ?>
<p><b>Erro:o tipo de atributo float unsigned não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo float unsigned não foi reconhecido.</b></p>
        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>