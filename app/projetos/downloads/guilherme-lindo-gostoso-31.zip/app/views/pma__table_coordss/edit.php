

<div class="page-header">
    <h1 class="page-title">Editar Pma__table_coords</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_coordss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__table_coordss/atualizar" method="POST">
<?php $obj = $pma__table_coords; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__table_coords['db_name'] ?? '') ?>">
<p><b>Erro:o tipo de atributo float unsigned não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo float unsigned não foi reconhecido.</b></p>
        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>