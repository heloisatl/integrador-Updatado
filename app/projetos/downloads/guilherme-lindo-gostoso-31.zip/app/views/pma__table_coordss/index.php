

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__table_coords</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_coordss/cadastrar" class="btn btn-primary">
            Novo Pma__table_coords
        </a>
    </div>
</div>

<?php if (empty($pma__table_coordss)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__table_coordss/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__table_coords
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Db_name</th>
                    <th>Table_name</th>
                    <th>Pdf_page_number</th>
                    <th>X</th>
                    <th>Y</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__table_coordss as $pma__table_coords): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__table_coords['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['pdf_page_number'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['x'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__table_coords['y'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__table_coordss/editar?id=<?= $pma__table_coords['db_name'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__table_coordss/excluir?id=<?= $pma__table_coords['db_name'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>