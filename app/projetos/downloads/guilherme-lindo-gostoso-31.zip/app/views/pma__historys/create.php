

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__history</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__historys" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__historys/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='username' id='username' value='<?= $obj?$obj['username']:''?>'><br>
<input type='text' name='db' id='db' value='<?= $obj?$obj['db']:''?>'><br>
<input type='text' name='table' id='table' value='<?= $obj?$obj['table']:''?>'><br>
<p><b>Erro:o tipo de atributo timestamp não foi reconhecido.</b></p><input type='text' name='sqlquery' id='sqlquery' value='<?= $obj?$obj['sqlquery']:''?>'><br>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>