

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__history</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__historys/cadastrar" class="btn btn-primary">
            Novo Pma__history
        </a>
    </div>
</div>

<?php if (empty($pma__historys)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__historys/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__history
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Username</th>
                    <th>Db</th>
                    <th>Table</th>
                    <th>Timevalue</th>
                    <th>Sqlquery</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__historys as $pma__history): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__history['id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['username'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['db'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['table'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['timevalue'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__history['sqlquery'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__historys/editar?id=<?= $pma__history['id'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__historys/excluir?id=<?= $pma__history['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>