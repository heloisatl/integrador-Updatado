

<div class="page-header">
    <h1 class="page-title">Editar Pma__history</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__historys" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__historys/atualizar" method="POST">
<?php $obj = $pma__history; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__history['id'] ?? '') ?>">
<input type='text' name='username' id='username' value='<?= $obj?$obj['username']:''?>'><br>
<input type='text' name='db' id='db' value='<?= $obj?$obj['db']:''?>'><br>
<input type='text' name='table' id='table' value='<?= $obj?$obj['table']:''?>'><br>
<p><b>Erro:o tipo de atributo timestamp não foi reconhecido.</b></p><input type='text' name='sqlquery' id='sqlquery' value='<?= $obj?$obj['sqlquery']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>