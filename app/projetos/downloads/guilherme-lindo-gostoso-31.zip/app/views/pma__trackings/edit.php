

<div class="page-header">
    <h1 class="page-title">Editar Pma__tracking</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__trackings" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__trackings/atualizar" method="POST">
<?php $obj = $pma__tracking; ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($pma__tracking['db_name'] ?? '') ?>">
<p><b>Erro:o tipo de atributo datetime não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo datetime não foi reconhecido.</b></p><input type='text' name='schema_snapshot' id='schema_snapshot' value='<?= $obj?$obj['schema_snapshot']:''?>'><br>
<input type='text' name='schema_sql' id='schema_sql' value='<?= $obj?$obj['schema_sql']:''?>'><br>
<p><b>Erro:o tipo de atributo longtext não foi reconhecido.</b></p><p><b>Erro:o tipo de atributo set('update','replace','insert','delete','truncate','create database','alter database','drop database','create table','alter table','rename table','drop table','create index','drop index','create view','alter view','drop view') não foi reconhecido.</b></p><input type='number' name='tracking_active' id='tracking_active' value='<?= $obj?$obj['tracking_active']:''?>'><br>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
</div>