

<div class="page-header">
    <h1 class="page-title">Listagem de Pma__tracking</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__trackings/cadastrar" class="btn btn-primary">
            Novo Pma__tracking
        </a>
    </div>
</div>

<?php if (empty($pma__trackings)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-text">Nenhum registro encontrado</div>
        <a href="<?= URL_BASE ?>/pma__trackings/cadastrar" class="btn btn-primary">
            Criar Primeiro Pma__tracking
        </a>
    </div>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Db_name</th>
                    <th>Table_name</th>
                    <th>Version</th>
                    <th>Date_created</th>
                    <th>Date_updated</th>
                    <th>Schema_snapshot</th>
                    <th>Schema_sql</th>
                    <th>Data_sql</th>
                    <th>Tracking</th>
                    <th>Tracking_active</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pma__trackings as $pma__tracking): ?>
                    <tr>
                        <td><?= htmlspecialchars($pma__tracking['db_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['table_name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['version'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['date_created'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['date_updated'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['schema_snapshot'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['schema_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['data_sql'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['tracking'] ?? '') ?></td>
                        <td><?= htmlspecialchars($pma__tracking['tracking_active'] ?? '') ?></td>
                        <td>
                            <a href="<?= URL_BASE ?>/pma__trackings/editar?id=<?= $pma__tracking['db_name'] ?>" class="btn btn-secondary btn-sm">Editar</a>
                            <a href="<?= URL_BASE ?>/pma__trackings/excluir?id=<?= $pma__tracking['db_name'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>