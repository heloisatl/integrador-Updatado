

<div class="page-header">
    <h1 class="page-title">Cadastrar Pma__table_uiprefs</h1>
    <div class="page-actions">
        <a href="<?= URL_BASE ?>/pma__table_uiprefss" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<div class="form-container">
    <form action="<?= URL_BASE ?>/pma__table_uiprefss/salvar" method="POST">
<?php $obj = null; ?>
<input type='text' name='prefs' id='prefs' value='<?= $obj?$obj['prefs']:''?>'><br>
<p><b>Erro:o tipo de atributo timestamp não foi reconhecido.</b></p>
        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>